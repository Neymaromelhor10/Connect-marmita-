import { describe, expect, it, beforeEach } from "vitest";
import { validateSupabaseClientConfig } from "@/integrations/supabase/client";
import { validateSupabaseServerConfig } from "@/integrations/supabase/client.server";
import {
  extractBearerTokenFromHeaders,
  verifyRemoteSupabaseSession,
} from "@/integrations/supabase/auth-middleware";
import { executeSetupCompany, executeSaveCompanyCustomer } from "./company.server";
import { handleDrainQueueRequest } from "@/routes/api/internal/whatsapp/drain-queue";
import { authErrorMessage } from "./auth-errors";
import {
  sanitizeDiagnosticMessage,
  extractErrorDiagnostics,
  logStructuredAuthDiagnostic,
} from "./auth-diagnostics";
import {
  handleHealthRequest,
  probeSupabaseAuthHealth,
  resetPublicHealthCacheForTest,
} from "@/routes/api/public/health";

describe("Argon 4 — Missão 7: Testes Obrigatórios de Conexão Vercel + Supabase", () => {
  beforeEach(() => {
    resetPublicHealthCacheForTest();
  });

  it("01. Supabase indisponível: probeSupabaseAuthHealth e verifyRemoteSupabaseSession tratam falha de rede", async () => {
    const failingFetch = (async () => {
      throw new TypeError("fetch failed");
    }) as unknown as typeof fetch;

    const probe = await probeSupabaseAuthHealth(
      "https://proj-test.supabase.co",
      "sb_publishable_valid_key_example_1234567890",
      failingFetch,
    );
    expect(probe).toEqual({ ok: false, httpStatus: null });

    const brokenAuthSupabase = {
      auth: {
        getUser: async () => {
          throw new TypeError("fetch failed");
        },
      },
    } as never;

    await expect(
      verifyRemoteSupabaseSession(brokenAuthSupabase, "user-1", "a.b.c"),
    ).rejects.toThrow(/SUPABASE_AUTH_UNREACHABLE/);

    expect(authErrorMessage(new Error("TypeError: Failed to fetch"))).toContain(
      "Sem conexão com o servidor",
    );
  });

  it("02. URL inválida: rejeita URL malformada, protocolo inválido e placeholder em client.ts e client.server.ts", () => {
    expect(() =>
      validateSupabaseClientConfig("nao-e-uma-url", "sb_publishable_12345678901234567890"),
    ).toThrow(/SUPABASE_URL_INVALID/);
    expect(() =>
      validateSupabaseClientConfig("https://SEU_PROJETO.supabase.co", "sb_publishable_1234567890"),
    ).toThrow(/SUPABASE_URL_INVALID/);
    expect(() =>
      validateSupabaseServerConfig("ftp://invalid.supabase.co", "sb_secret_valid_key_123456"),
    ).toThrow(/SUPABASE_URL_INVALID/);
    expect(authErrorMessage(new Error("SUPABASE_URL_INVALID"))).toContain(
      "temporariamente indisponível",
    );
  });

  it("03. Chave ausente ou chave pública indevida em SUPABASE_SERVICE_ROLE_KEY", () => {
    expect(() => validateSupabaseClientConfig("https://ok.supabase.co", "")).toThrow(
      /SUPABASE_CONFIG_MISSING/,
    );
    expect(() => validateSupabaseServerConfig("https://ok.supabase.co", "")).toThrow(
      /SUPABASE_CONFIG_MISSING/,
    );
    expect(() =>
      validateSupabaseServerConfig(
        "https://ok.supabase.co",
        "sb_publishable_chave_errada_em_service_role",
      ),
    ).toThrow(/SUPABASE_SERVER_CONFIG_INVALID/);
  });

  it("04. Token ausente: extractBearerTokenFromHeaders bloqueia ausência de headers ou Bearer vazio", () => {
    expect(() => extractBearerTokenFromHeaders(null)).toThrow(/TOKEN_MISSING/);
    expect(() => extractBearerTokenFromHeaders(new Headers())).toThrow(/TOKEN_MISSING/);
    expect(() =>
      extractBearerTokenFromHeaders(new Headers({ authorization: "Bearer   " })),
    ).toThrow(/TOKEN_MISSING/);
  });

  it("05. Token inválido: rejeita JWT malformado e token rejeitado pelo Supabase Auth", async () => {
    expect(() =>
      extractBearerTokenFromHeaders(new Headers({ authorization: "Basic abc" })),
    ).toThrow(/TOKEN_INVALID/);
    expect(() =>
      extractBearerTokenFromHeaders(new Headers({ authorization: "Bearer token-sem-pontos" })),
    ).toThrow(/TOKEN_INVALID/);

    const invalidAuthSupabase = {
      auth: {
        getUser: async () => ({
          data: { user: null },
          error: { status: 401, code: "bad_jwt", message: "invalid JWT signature" },
        }),
      },
    } as never;

    await expect(
      verifyRemoteSupabaseSession(invalidAuthSupabase, "user-1", "a.b.c"),
    ).rejects.toThrow(/TOKEN_INVALID/);
  });

  it("06. Token expirado: verifyRemoteSupabaseSession identifica TOKEN_EXPIRED e authErrorMessage orienta novo login", async () => {
    const expiredAuthSupabase = {
      auth: {
        getUser: async () => ({
          data: { user: null },
          error: { status: 401, code: "jwt_expired", message: "JWT expired" },
        }),
      },
    } as never;

    await expect(
      verifyRemoteSupabaseSession(expiredAuthSupabase, "user-1", "a.b.c"),
    ).rejects.toThrow(/TOKEN_EXPIRED/);

    expect(authErrorMessage(new Error("Unauthorized (TOKEN_EXPIRED): Token expirado."))).toBe(
      "Sua sessão expirou. Faça login novamente.",
    );
  });

  it("07. Falha de comunicação entre frontend e Server Function + sanitização segura de logs (nunca vaza JWT/senha/chaves)", () => {
    const leaky =
      "Failed Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijk123456 sb_secret_supersegredo123 user@test.com password=minhasenha";
    const sanitized = sanitizeDiagnosticMessage(leaky);
    expect(sanitized).not.toContain("eyJhbGci");
    expect(sanitized).not.toContain("sb_secret_supersegredo123");
    expect(sanitized).not.toContain("user@test.com");
    expect(sanitized).not.toContain("minhasenha");

    const logEntry = logStructuredAuthDiagnostic({
      operation: "auth_signup",
      stage: "server_fn_setup_company",
      error: new Error("SETUP_COMPANY_FAILED"),
    });
    expect(logEntry.operation).toBe("auth_signup");
    expect(logEntry.stage).toBe("server_fn_setup_company");
    expect(logEntry.errorCode).toBe("SETUP_COMPANY_FAILED");
    expect(logEntry.correlationId.length).toBeGreaterThan(5);
  });

  it("08 & 12. Cadastro com sessão e criação efetiva da empresa (companies + profiles + user_roles + financial_permissions)", async () => {
    const inserted: string[] = [];
    const mockAdmin = {
      from: (table: string) => {
        if (table === "profiles") {
          return {
            select: () => ({
              eq: () => ({
                maybeSingle: async () => ({ data: null, error: null }),
              }),
            }),
            insert: async () => {
              inserted.push("profiles");
              return { error: null };
            },
          };
        }
        if (table === "companies") {
          return {
            insert: () => ({
              select: () => ({
                single: async () => {
                  inserted.push("companies");
                  return { data: { id: "comp-new-01" }, error: null };
                },
              }),
            }),
          };
        }
        if (table === "user_roles") {
          return {
            insert: async () => {
              inserted.push("user_roles");
              return { error: null };
            },
          };
        }
        if (table === "financial_permissions") {
          return {
            upsert: async () => {
              inserted.push("financial_permissions");
              return { error: null };
            },
          };
        }
        throw new Error(`Unexpected table ${table}`);
      },
    } as never;

    const validAuthSupabase = {
      auth: {
        getUser: async () => ({
          data: { user: { id: "user-new-01", email: "dono@marmita.test", user_metadata: {} } },
          error: null,
        }),
      },
    } as never;

    const res = await executeSetupCompany(
      {
        supabase: validAuthSupabase,
        userId: "user-new-01",
        token: "a.b.c",
        claims: { email: "dono@marmita.test" },
      },
      { companyName: "Marmitaria Teste", fullName: "João" },
      { supabaseAdmin: mockAdmin },
    );

    expect(res).toEqual({ companyId: "comp-new-01" });
    expect(inserted).toEqual(["companies", "profiles", "user_roles", "financial_permissions"]);
  });

  it("09, 10 & 11. Cadastro exigindo confirmação de e-mail, login válido e login inválido", () => {
    expect(authErrorMessage(new Error("Email not confirmed"))).toBe(
      "Confirme seu e-mail antes de entrar.",
    );
    expect(authErrorMessage(new Error("Invalid login credentials"))).toBe(
      "E-mail ou senha incorretos.",
    );
    expect(authErrorMessage(new Error("User already registered"))).toBe(
      "Este e-mail já está cadastrado. Faça login.",
    );
  });

  it("13. Empresa já existente: executeSetupCompany retorna companyId de forma idempotente sem recriar", async () => {
    let companyInsertCalled = false;
    const mockAdmin = {
      from: (table: string) => {
        if (table === "profiles") {
          return {
            select: () => ({
              eq: () => ({
                maybeSingle: async () => ({ data: { company_id: "comp-existing-99" }, error: null }),
              }),
            }),
          };
        }
        if (table === "companies") {
          companyInsertCalled = true;
          throw new Error("Não deveria inserir nova empresa quando já existe!");
        }
        throw new Error(`Unexpected table ${table}`);
      },
    } as never;

    const validAuthSupabase = {
      auth: {
        getUser: async () => ({
          data: { user: { id: "user-existing-99", email: "dono@marmita.test", user_metadata: {} } },
          error: null,
        }),
      },
    } as never;

    const res = await executeSetupCompany(
      { supabase: validAuthSupabase, userId: "user-existing-99", token: "a.b.c" },
      { companyName: "Outra", fullName: "Dono" },
      { supabaseAdmin: mockAdmin },
    );
    expect(res).toEqual({ companyId: "comp-existing-99" });
    expect(companyInsertCalled).toBe(false);
  });

  it("14. Falha de PostgreSQL: executeSetupCompany propaga POSTGRES_ERROR sem engolir falha", async () => {
    const mockAdmin = {
      from: () => ({
        select: () => ({
          eq: () => ({
            maybeSingle: async () => ({
              data: null,
              error: { code: "08006", message: "connection failure" },
            }),
          }),
        }),
      }),
    } as never;

    const validAuthSupabase = {
      auth: {
        getUser: async () => ({
          data: { user: { id: "user-pg-fail", email: "dono@marmita.test", user_metadata: {} } },
          error: null,
        }),
      },
    } as never;

    await expect(
      executeSetupCompany(
        { supabase: validAuthSupabase, userId: "user-pg-fail", token: "a.b.c" },
        { companyName: "Teste", fullName: "Dono" },
        { supabaseAdmin: mockAdmin },
      ),
    ).rejects.toThrow(/POSTGRES_ERROR/);
  });

  it("15. Erro 500 no backend e /api/public/health separado (público sem segredos vs. admin protegido)", async () => {
    const diag = extractErrorDiagnostics({ status: 500, message: "Internal Server Error" });
    expect(diag.httpStatus).toBe(500);
    expect(diag.errorCode).toBe("BACKEND_HTTP_5XX");
    expect(authErrorMessage(new Error("HTTP 500 Internal Server Error"))).toBe(
      "O servidor encontrou um erro temporário. Tente novamente em instantes.",
    );

    const prevUrl = process.env["SUPABASE_URL"];
    const prevAnon = process.env["SUPABASE_ANON_KEY"];
    const prevSrv = process.env["SUPABASE_SERVICE_ROLE_KEY"];
    const prevCron = process.env["CRON_SECRET"];

    try {
      process.env["SUPABASE_URL"] = "https://valid-project.supabase.co";
      process.env["SUPABASE_ANON_KEY"] = "sb_publishable_valid_anon_key_1234567890";
      process.env["SUPABASE_SERVICE_ROLE_KEY"] = "sb_secret_valid_service_key_1234567890";
      process.env["CRON_SECRET"] = "super-secret-cron-token-1234567890";

      const okFetch = (async () => new Response("{}", { status: 200 })) as unknown as typeof fetch;
      const okAdmin = {
        from: () => ({
          select: () => ({
            limit: async () => ({ data: [{ id: "c1" }], error: null }),
          }),
        }),
      };

      const pubRes = await handleHealthRequest(
        new Request("https://marmita.test/api/public/health"),
        { fetchImpl: okFetch, supabaseAdminOverride: okAdmin },
      );
      expect(pubRes.status).toBe(200);
      const pubJson = (await pubRes.json()) as Record<string, unknown>;
      expect(pubJson.status).toBe("ok");
      expect(pubJson.checks).toEqual({
        server: "ok",
        supabaseConfig: "ok",
        postgresql: "ok",
        supabaseAuth: "ok",
      });
      // Garante que a resposta pública NÃO expõe segredos nem diagnóstico administrativo
      expect(pubJson.configDiagnostics).toBeUndefined();
      expect(pubJson.configuredIntegrations).toBeUndefined();
      expect(pubJson.queue).toBeUndefined();
    } finally {
      if (prevUrl === undefined) delete process.env["SUPABASE_URL"];
      else process.env["SUPABASE_URL"] = prevUrl;
      if (prevAnon === undefined) delete process.env["SUPABASE_ANON_KEY"];
      else process.env["SUPABASE_ANON_KEY"] = prevAnon;
      if (prevSrv === undefined) delete process.env["SUPABASE_SERVICE_ROLE_KEY"];
      else process.env["SUPABASE_SERVICE_ROLE_KEY"] = prevSrv;
      if (prevCron === undefined) delete process.env["CRON_SECRET"];
      else process.env["CRON_SECRET"] = prevCron;
    }
  });

  it("16. Missão 9 — Requisições repetidas e concorrentes em executeSetupCompany coalescem em 1 única criação (sem duplicar empresa)", async () => {
    let companyInsertCount = 0;
    const mockAdmin = {
      from: (table: string) => {
        if (table === "profiles") {
          return {
            select: () => ({
              eq: () => ({
                maybeSingle: async () => {
                  await new Promise((r) => setTimeout(r, 15));
                  return { data: null, error: null };
                },
              }),
            }),
            insert: async () => ({ error: null }),
          };
        }
        if (table === "companies") {
          return {
            insert: () => ({
              select: () => ({
                single: async () => {
                  companyInsertCount++;
                  return { data: { id: "comp-coalesced-01" }, error: null };
                },
              }),
            }),
          };
        }
        if (table === "user_roles") return { insert: async () => ({ error: null }) };
        if (table === "financial_permissions") return { upsert: async () => ({ error: null }) };
        throw new Error(`Unexpected table ${table}`);
      },
    } as never;

    const validAuthSupabase = {
      auth: {
        getUser: async () => ({
          data: { user: { id: "user-concurrent-01", email: "c@marmita.test", user_metadata: {} } },
          error: null,
        }),
      },
    } as never;

    const [r1, r2] = await Promise.all([
      executeSetupCompany(
        { supabase: validAuthSupabase, userId: "user-concurrent-01", token: "a.b.c" },
        { companyName: "Marmitaria Concorrente", fullName: "Ana" },
        { supabaseAdmin: mockAdmin },
      ),
      executeSetupCompany(
        { supabase: validAuthSupabase, userId: "user-concurrent-01", token: "a.b.c" },
        { companyName: "Marmitaria Concorrente", fullName: "Ana" },
        { supabaseAdmin: mockAdmin },
      ),
    ]);

    expect(r1.companyId).toBe("comp-coalesced-01");
    expect(r2.companyId).toBe("comp-coalesced-01");
    expect(companyInsertCount).toBe(1);
  });

  it("17. Missão 9 — Isolamento multiempresa: operador da Empresa A não consegue alterar cliente da Empresa B", async () => {
    const authSupabaseA = {
      auth: {
        getUser: async () => ({
          data: { user: { id: "user-a", email: "a@marmita.test", user_metadata: {} } },
          error: null,
        }),
      },
      from: () => ({
        select: () => ({
          eq: () => ({
            maybeSingle: async () => ({ data: { company_id: "comp-A" }, error: null }),
          }),
        }),
      }),
      rpc: async (fn: string) => {
        if (fn === "financial_require_operator") return { data: "comp-A", error: null };
        if (fn === "upsert_company_customer") {
          return { data: null, error: { code: "PGRST202", message: "fallback test" } };
        }
        return { data: null, error: null };
      },
    } as never;

    const adminWithCustomerB = {
      from: () => ({
        select: () => ({
          eq: () => ({
            maybeSingle: async () => ({
              data: { id: "11111111-1111-4111-8111-111111111111", company_id: "comp-B", phone: "11999998888" },
              error: null,
            }),
          }),
        }),
      }),
    } as never;

    await expect(
      executeSaveCompanyCustomer(
        { supabase: authSupabaseA, userId: "user-a", token: "a.b.c" },
        {
          id: "11111111-1111-4111-8111-111111111111",
          name: "Tentativa Cross-Tenant",
          phone: "11999998888",
          payment_cycle: "semanal",
        },
        { supabaseAdmin: adminWithCustomerB },
      ),
    ).rejects.toThrow(/Acesso negado/);
  });

  it("18. Missão 9 — Proteção de endpoints administrativos (/api/internal/whatsapp/drain-queue 401 sem segredo e /api/public/health admin sem vazar segredos)", async () => {
    const unauthDrain = await handleDrainQueueRequest(
      new Request("https://marmita.test/api/internal/whatsapp/drain-queue"),
      { env: { CRON_SECRET: "real-cron-secret-1234567890" } },
    );
    expect(unauthDrain.status).toBe(401);

    const prevUrl = process.env["SUPABASE_URL"];
    const prevAnon = process.env["SUPABASE_ANON_KEY"];
    const prevSrv = process.env["SUPABASE_SERVICE_ROLE_KEY"];
    const prevCron = process.env["CRON_SECRET"];
    try {
      process.env["SUPABASE_URL"] = "https://valid-project.supabase.co";
      process.env["SUPABASE_ANON_KEY"] = "sb_publishable_valid_anon_key_1234567890";
      process.env["SUPABASE_SERVICE_ROLE_KEY"] = "sb_secret_super_hidden_value_999999";
      process.env["CRON_SECRET"] = "real-cron-secret-1234567890";

      const okFetch = (async () => new Response("{}", { status: 200 })) as unknown as typeof fetch;
      const okAdmin = {
        from: () => ({
          select: () => ({
            limit: async () => ({ data: [{ id: "c1" }], error: null }),
            eq: () => ({ head: true, count: 0 }),
          }),
        }),
      };

      const adminRes = await handleHealthRequest(
        new Request("https://marmita.test/api/public/health", {
          headers: { authorization: "Bearer real-cron-secret-1234567890" },
        }),
        { fetchImpl: okFetch, supabaseAdminOverride: okAdmin as never },
      );
      const rawText = await adminRes.text();
      expect(rawText).not.toContain("sb_secret_super_hidden_value_999999");
      expect(rawText).not.toContain("real-cron-secret-1234567890");
      const parsed = JSON.parse(rawText) as { configDiagnostics?: Record<string, boolean> };
      expect(parsed.configDiagnostics?.supabaseServiceRoleNotPublishable).toBe(true);
    } finally {
      if (prevUrl === undefined) delete process.env["SUPABASE_URL"];
      else process.env["SUPABASE_URL"] = prevUrl;
      if (prevAnon === undefined) delete process.env["SUPABASE_ANON_KEY"];
      else process.env["SUPABASE_ANON_KEY"] = prevAnon;
      if (prevSrv === undefined) delete process.env["SUPABASE_SERVICE_ROLE_KEY"];
      else process.env["SUPABASE_SERVICE_ROLE_KEY"] = prevSrv;
      if (prevCron === undefined) delete process.env["CRON_SECRET"];
      else process.env["CRON_SECRET"] = prevCron;
    }
  });
});
