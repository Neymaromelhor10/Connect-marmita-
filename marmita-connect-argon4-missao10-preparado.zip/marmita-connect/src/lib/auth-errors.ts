/**
 * Traduz erros técnicos de autenticação, configuração e backend em mensagens seguras
 * e compreensíveis para o usuário final, sem expor detalhes internos ou segredos.
 */
export function authErrorMessage(error: unknown): string {
  const raw = (error instanceof Error ? error.message : String(error ?? "")).toLowerCase();

  if (
    raw.includes("supabase_config_missing") ||
    raw.includes("supabase_server_config_invalid") ||
    raw.includes("supabase_url_invalid") ||
    raw.includes("missing supabase environment variable")
  ) {
    return "Serviço de autenticação temporariamente indisponível por configuração do ambiente. Tente novamente em instantes.";
  }

  if (raw.includes("token_expired") || raw.includes("jwt expired")) {
    return "Sua sessão expirou. Faça login novamente.";
  }

  if (
    raw.includes("token_missing") ||
    raw.includes("token_invalid") ||
    raw.includes("unauthorized")
  ) {
    return "Não foi possível validar sua sessão. Faça login novamente.";
  }

  if (raw.includes("supabase_auth_unreachable")) {
    return "Não foi possível alcançar o serviço de autenticação. Tente novamente em instantes.";
  }

  if (raw.includes("setup_company_failed") || raw.includes("postgres_error")) {
    return "Sua conta foi autenticada, mas não foi possível concluir a configuração da marmitaria no servidor. Tente novamente.";
  }

  if (raw.includes("invalid login credentials")) return "E-mail ou senha incorretos.";
  if (raw.includes("email not confirmed")) return "Confirme seu e-mail antes de entrar.";
  if (raw.includes("user already registered") || raw.includes("already been registered"))
    return "Este e-mail já está cadastrado. Faça login.";
  if (raw.includes("pwned") || raw.includes("compromised") || raw.includes("easy to guess"))
    return "Essa senha é muito comum e insegura. Escolha outra mais forte.";
  if (raw.includes("password should be at least") || raw.includes("weak"))
    return "A senha precisa ter pelo menos 6 caracteres e não pode ser muito comum.";

  if (raw.includes("invalid email") || raw.includes("unable to validate email"))
    return "Digite um e-mail válido.";
  if (raw.includes("rate limit") || raw.includes("too many"))
    return "Muitas tentativas. Aguarde alguns minutos e tente de novo.";
  if (raw.includes("same password"))
    return "A nova senha precisa ser diferente da anterior.";
  if (raw.includes("expired") || raw.includes("invalid token"))
    return "O link expirou. Solicite a recuperação de senha novamente.";

  if (
    raw.includes("failed to fetch") ||
    raw.includes("fetch failed") ||
    raw.includes("networkerror") ||
    raw.includes("load failed") ||
    raw.includes("econnrefused") ||
    raw.includes("enotfound") ||
    raw.includes("err_name_not_resolved") ||
    raw.includes("network")
  ) {
    return "Sem conexão com o servidor. Verifique sua internet ou tente novamente em instantes.";
  }

  if (raw.includes("500") || raw.includes("502") || raw.includes("503") || raw.includes("504")) {
    return "O servidor encontrou um erro temporário. Tente novamente em instantes.";
  }

  return "Não foi possível concluir a operação. Tente novamente.";
}
