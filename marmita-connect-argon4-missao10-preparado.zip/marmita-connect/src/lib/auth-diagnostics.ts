/**
 * Diagnóstico estruturado e seguro para o fluxo de autenticação e conexão Supabase/Vercel.
 * - Registra apenas metadados técnicos: operação, etapa, código HTTP, código Supabase,
 *   identificador de correlação e ambiente de execução.
 * - Sanitiza automaticamente qualquer token JWT, Bearer, chave sb_secret_/sb_publishable_,
 *   e-mail ou senha que possa aparecer em mensagens de erro de terceiros.
 */

export type AuthOperationName =
  | "auth_signup"
  | "auth_login"
  | "auth_oauth_google"
  | "auth_reset_password"
  | "auth_middleware"
  | "setup_company"
  | "health_check";

export type StructuredAuthLogPayload = {
  level: "error" | "warn" | "info";
  type: "auth_connection_diagnostic";
  operation: AuthOperationName;
  stage: string;
  correlationId: string;
  httpStatus: number | null;
  supabaseErrorCode: string | null;
  errorCode: string;
  runtimeEnv: string;
  timestamp: string;
  detail?: string;
};

export function createCorrelationId(): string {
  if (typeof globalThis.crypto !== "undefined" && typeof globalThis.crypto.randomUUID === "function") {
    return globalThis.crypto.randomUUID();
  }
  return `corr-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function detectRuntimeEnv(): string {
  if (typeof window !== "undefined") {
    return "browser";
  }
  if (typeof process !== "undefined" && process.env) {
    if (process.env["VERCEL"] === "1" || process.env["VERCEL_ENV"]) {
      return `vercel:${process.env["VERCEL_ENV"] || "unknown"}`;
    }
    return `node:${process.env["NODE_ENV"] || "development"}`;
  }
  return "unknown";
}

export function sanitizeDiagnosticMessage(raw: unknown): string {
  const text = raw instanceof Error ? raw.message : raw && typeof raw === "object" && "message" in raw && typeof (raw as { message?: unknown }).message === "string" ? (raw as { message: string }).message : String(raw ?? "");
  return text
    .replace(/Bearer\s+[A-Za-z0-9\-._~+/]+=*/gi, "Bearer [REDACTED]")
    .replace(/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, "[JWT_REDACTED]")
    .replace(/sb_(?:secret|publishable)_[A-Za-z0-9_-]+/gi, "[SUPABASE_KEY_REDACTED]")
    .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, "[EMAIL_REDACTED]")
    .replace(/(password|senha|secret|apikey|api_key)\s*[:=]\s*[^\s,;]+/gi, "$1=[REDACTED]")
    .slice(0, 260);
}

export function extractErrorDiagnostics(error: unknown): {
  httpStatus: number | null;
  supabaseErrorCode: string | null;
  errorCode: string;
} {
  const errObj =
    error && typeof error === "object"
      ? (error as {
          status?: unknown;
          statusCode?: unknown;
          code?: unknown;
          name?: unknown;
          message?: unknown;
        })
      : null;

  const rawStatus =
    typeof errObj?.status === "number"
      ? errObj.status
      : typeof errObj?.statusCode === "number"
        ? errObj.statusCode
        : null;

  const supabaseErrorCode =
    typeof errObj?.code === "string" && errObj.code.trim() ? errObj.code.trim() : null;

  const msg = error instanceof Error ? error.message : String(error ?? "");
  const lower = msg.toLowerCase();

  let errorCode = "UNKNOWN_AUTH_ERROR";
  if (lower.includes("supabase_config_missing") || lower.includes("missing supabase environment")) {
    errorCode = "SUPABASE_CONFIG_MISSING";
  } else if (lower.includes("supabase_server_config_invalid")) {
    errorCode = "SUPABASE_SERVER_CONFIG_INVALID";
  } else if (lower.includes("supabase_url_invalid")) {
    errorCode = "SUPABASE_URL_INVALID";
  } else if (lower.includes("token_expired") || lower.includes("jwt expired")) {
    errorCode = "TOKEN_EXPIRED";
  } else if (lower.includes("token_missing") || lower.includes("no authorization header")) {
    errorCode = "TOKEN_MISSING";
  } else if (lower.includes("token_invalid") || lower.includes("invalid token")) {
    errorCode = "TOKEN_INVALID";
  } else if (lower.includes("setup_company_failed")) {
    errorCode = "SETUP_COMPANY_FAILED";
  } else if (lower.includes("supabase_auth_unreachable")) {
    errorCode = "SUPABASE_AUTH_UNREACHABLE";
  } else if (lower.includes("postgres_error") || lower.includes("database")) {
    errorCode = "POSTGRES_ERROR";
  } else if (
    lower.includes("failed to fetch") ||
    lower.includes("fetch failed") ||
    lower.includes("network") ||
    lower.includes("econnrefused") ||
    lower.includes("enotfound")
  ) {
    errorCode = "NETWORK_UNREACHABLE";
  } else if (rawStatus && rawStatus >= 500) {
    errorCode = "BACKEND_HTTP_5XX";
  } else if (supabaseErrorCode) {
    errorCode = supabaseErrorCode;
  }

  return { httpStatus: rawStatus, supabaseErrorCode, errorCode };
}

export function logStructuredAuthDiagnostic(input: {
  level?: "error" | "warn" | "info";
  operation: AuthOperationName;
  stage: string;
  correlationId?: string;
  error?: unknown;
  httpStatus?: number | null;
  supabaseErrorCode?: string | null;
  errorCode?: string;
}): StructuredAuthLogPayload {
  const extracted = input.error ? extractErrorDiagnostics(input.error) : null;
  const payload: StructuredAuthLogPayload = {
    level: input.level ?? "error",
    type: "auth_connection_diagnostic",
    operation: input.operation,
    stage: input.stage,
    correlationId: input.correlationId ?? createCorrelationId(),
    httpStatus: input.httpStatus ?? extracted?.httpStatus ?? null,
    supabaseErrorCode: input.supabaseErrorCode ?? extracted?.supabaseErrorCode ?? null,
    errorCode: input.errorCode ?? extracted?.errorCode ?? "DIAGNOSTIC_EVENT",
    runtimeEnv: detectRuntimeEnv(),
    timestamp: new Date().toISOString(),
    ...(input.error ? { detail: sanitizeDiagnosticMessage(input.error) } : {}),
  };

  const serialized = JSON.stringify(payload);
  if (payload.level === "error") {
    console.error(serialized);
  } else if (payload.level === "warn") {
    console.warn(serialized);
  } else {
    console.info(serialized);
  }
  return payload;
}
