import { createFileRoute } from "@tanstack/react-router";
import {
  authenticateCronRequest,
  inspectOperationalQueueHealth,
} from "@/lib/operational-alerts.server";
import {
  createCorrelationId,
  detectRuntimeEnv,
  logStructuredAuthDiagnostic,
} from "@/lib/auth-diagnostics";

const PUBLIC_HEALTH_CACHE_TTL_MS = 5_000;

type CheckStatus = "ok" | "error";

type PublicHealthChecks = {
  server: "ok";
  supabaseConfig: CheckStatus;
  postgresql: CheckStatus;
  supabaseAuth: CheckStatus;
};

let cachedPublicHealth: {
  expiresAtMs: number;
  statusHttp: number;
  body: {
    status: "ok" | "degraded" | "down";
    checks: PublicHealthChecks;
    checkedAt: string;
  };
} | null = null;

export function resetPublicHealthCacheForTest() {
  cachedPublicHealth = null;
}

function isPlaceholder(val: string | undefined): boolean {
  const s = (val ?? "").trim().toLowerCase();
  return (
    !s ||
    s.includes("seu_projeto") ||
    s.includes("sua_chave") ||
    s.includes("sua_service_role") ||
    s.includes("placeholder")
  );
}

function isValidHttpUrl(val: string | undefined): boolean {
  const s = (val ?? "").trim();
  if (!s || isPlaceholder(s)) return false;
  try {
    const u = new URL(s);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}

export async function probeSupabaseAuthHealth(
  supabaseUrl: string,
  anonKey: string,
  fetchImpl: typeof fetch = fetch,
): Promise<{ ok: boolean; httpStatus: number | null }> {
  if (!isValidHttpUrl(supabaseUrl)) {
    return { ok: false, httpStatus: null };
  }
  const baseUrl = supabaseUrl.trim().replace(/\/$/, "");
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5_000);
    try {
      const res = await fetchImpl(`${baseUrl}/auth/v1/health`, {
        method: "GET",
        headers: anonKey ? { apikey: anonKey } : {},
        signal: controller.signal,
      });
      return { ok: res.ok, httpStatus: res.status };
    } finally {
      clearTimeout(timer);
    }
  } catch {
    return { ok: false, httpStatus: null };
  }
}

/**
 * CORREÇÃO FOR-11 & MISSÃO 5 (Vercel + Supabase):
 * - Separa os testes de:
 *     1. Disponibilidade do servidor (`checks.server`)
 *     2. Configuração do Supabase (`checks.supabaseConfig`)
 *     3. Conexão com PostgreSQL (`checks.postgresql`)
 *     4. Disponibilidade do Supabase Auth (`checks.supabaseAuth`)
 * - Resposta pública (sem `CRON_SECRET`): retorna exclusivamente status agregado e
 *   indicadores `ok`/`error` por camada, sem jamais expor segredos, URLs, contagens
 *   da fila ou mensagens internas.
 * - Diagnóstico administrativo protegido (`Authorization: Bearer <CRON_SECRET>`):
 *   retorna diagnóstico detalhado por camada (sem valores de segredos) e métricas da fila.
 */
export async function handleHealthRequest(
  request?: Request,
  deps?: {
    fetchImpl?: typeof fetch;
    supabaseAdminOverride?: {
      from: (table: string) => { select: (cols: string) => { limit: (n: number) => PromiseLike<{ error: unknown }> } };
    };
  },
): Promise<Response> {
  const isAuthorizedMonitor = request ? authenticateCronRequest(request) : false;
  const nowMs = Date.now();
  const correlationId = createCorrelationId();

  if (!isAuthorizedMonitor && cachedPublicHealth && cachedPublicHealth.expiresAtMs > nowMs) {
    return new Response(JSON.stringify(cachedPublicHealth.body), {
      status: cachedPublicHealth.statusHttp,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "public, max-age=5",
      },
    });
  }

  const serverSupabaseUrl = (process.env["SUPABASE_URL"] || process.env["VITE_SUPABASE_URL"] || "").trim();
  const viteSupabaseUrl = (process.env["VITE_SUPABASE_URL"] || "").trim();
  const anonKey = (
    process.env["SUPABASE_ANON_KEY"] ||
    process.env["SUPABASE_PUBLISHABLE_KEY"] ||
    process.env["VITE_SUPABASE_ANON_KEY"] ||
    process.env["VITE_SUPABASE_PUBLISHABLE_KEY"] ||
    ""
  ).trim();
  const serviceRoleKey = (process.env["SUPABASE_SERVICE_ROLE_KEY"] || "").trim();

  const configDiagnostics = {
    supabaseUrlConfigured: Boolean(serverSupabaseUrl) && !isPlaceholder(serverSupabaseUrl),
    supabaseUrlValid: isValidHttpUrl(serverSupabaseUrl),
    supabaseAnonKeyConfigured: Boolean(anonKey) && !isPlaceholder(anonKey),
    supabaseServiceRoleConfigured: Boolean(serviceRoleKey) && !isPlaceholder(serviceRoleKey),
    supabaseServiceRoleNotPublishable:
      Boolean(serviceRoleKey) && !serviceRoleKey.startsWith("sb_publishable_"),
    vitePublicUrlAligned:
      !viteSupabaseUrl || !serverSupabaseUrl || viteSupabaseUrl.replace(/\/$/, "") === serverSupabaseUrl.replace(/\/$/, ""),
  };

  const supabaseConfigOk =
    configDiagnostics.supabaseUrlConfigured &&
    configDiagnostics.supabaseUrlValid &&
    configDiagnostics.supabaseAnonKeyConfigured &&
    configDiagnostics.supabaseServiceRoleConfigured &&
    configDiagnostics.supabaseServiceRoleNotPublishable;

  const requiredEnv = {
    supabaseUrl: configDiagnostics.supabaseUrlValid,
    supabaseServiceRole:
      configDiagnostics.supabaseServiceRoleConfigured &&
      configDiagnostics.supabaseServiceRoleNotPublishable,
    geminiApiKey: Boolean(process.env["GEMINI_API_KEY"]),
    whatsappVerifyToken: Boolean(process.env["WHATSAPP_VERIFY_TOKEN"]),
    whatsappAppSecret: Boolean(process.env["WHATSAPP_APP_SECRET"]),
  };

  const authProbe = await probeSupabaseAuthHealth(
    serverSupabaseUrl,
    anonKey,
    deps?.fetchImpl ?? fetch,
  );

  let dbConnected = false;
  let queueHealth: Awaited<ReturnType<typeof inspectOperationalQueueHealth>> | null = null;
  const checkedAt = new Date(nowMs).toISOString();

  try {
    const adminClient =
      deps?.supabaseAdminOverride ?? (await import("@/integrations/supabase/client.server")).supabaseAdmin;

    if (!isAuthorizedMonitor) {
      const ping = await adminClient.from("companies").select("id").limit(1);
      dbConnected = !ping.error;
    } else {
      queueHealth = await inspectOperationalQueueHealth(adminClient as never);
      dbConnected = queueHealth.dbConnected;
    }
  } catch (err) {
    dbConnected = false;
    logStructuredAuthDiagnostic({
      operation: "health_check",
      stage: "postgresql_ping",
      correlationId,
      error: err,
    });
  }

  const checks: PublicHealthChecks = {
    server: "ok",
    supabaseConfig: supabaseConfigOk ? "ok" : "error",
    postgresql: dbConnected ? "ok" : "error",
    supabaseAuth: authProbe.ok ? "ok" : "error",
  };

  const allCriticalOk =
    checks.supabaseConfig === "ok" && checks.postgresql === "ok" && checks.supabaseAuth === "ok";
  const overallStatus: "ok" | "degraded" | "down" = allCriticalOk
    ? queueHealth && !queueHealth.healthy
      ? "degraded"
      : "ok"
    : dbConnected || authProbe.ok
      ? "degraded"
      : "down";
  const statusHttp = allCriticalOk ? 200 : 503;

  if (!isAuthorizedMonitor) {
    const publicBody = {
      status: overallStatus,
      checks,
      checkedAt,
    };

    cachedPublicHealth = {
      expiresAtMs: nowMs + PUBLIC_HEALTH_CACHE_TTL_MS,
      statusHttp,
      body: publicBody,
    };

    return new Response(JSON.stringify(publicBody), {
      status: statusHttp,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": allCriticalOk ? "public, max-age=5" : "no-store",
      },
    });
  }

  return new Response(
    JSON.stringify({
      status: overallStatus,
      checks,
      dbConnected,
      authReachable: authProbe.ok,
      authHttpStatus: authProbe.httpStatus,
      configDiagnostics,
      queue: queueHealth?.counts ?? null,
      configuredIntegrations: requiredEnv,
      runtimeEnv: detectRuntimeEnv(),
      correlationId,
      checkedAt: queueHealth?.checkedAt ?? checkedAt,
    }),
    {
      status: statusHttp,
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "no-store",
      },
    },
  );
}

export const Route = createFileRoute("/api/public/health")({
  server: {
    handlers: {
      GET: async ({ request }) => handleHealthRequest(request),
    },
  },
});
