import { createMiddleware } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "./types";
import {
  createCorrelationId,
  logStructuredAuthDiagnostic,
} from "@/lib/auth-diagnostics";

function isNewSupabaseApiKey(value: string): boolean {
  return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}

function isPlaceholderValue(value: string): boolean {
  const lower = value.trim().toLowerCase();
  return (
    !lower ||
    lower.includes("seu_projeto") ||
    lower.includes("sua_chave") ||
    lower.includes("placeholder")
  );
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );

    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }

    if (
      isNewSupabaseApiKey(supabaseKey) &&
      headers.get("Authorization") === `Bearer ${supabaseKey}`
    ) {
      headers.delete("Authorization");
    }

    headers.set("apikey", supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

export function extractBearerTokenFromHeaders(
  headers: Pick<Headers, "get"> | null | undefined,
): string {
  if (!headers) {
    throw new Error("Unauthorized (TOKEN_MISSING): No request headers available");
  }
  const authHeader = headers.get("authorization");
  if (!authHeader) {
    throw new Error("Unauthorized (TOKEN_MISSING): No authorization header provided");
  }
  const trimmedHeader = authHeader.trim();
  if (trimmedHeader === "Bearer") {
    throw new Error("Unauthorized (TOKEN_MISSING): Empty Bearer token");
  }
  if (!trimmedHeader.startsWith("Bearer ")) {
    throw new Error("Unauthorized (TOKEN_INVALID): Only Bearer tokens are supported");
  }
  const token = trimmedHeader.slice(7).trim();
  if (!token) {
    throw new Error("Unauthorized (TOKEN_MISSING): Empty Bearer token");
  }
  if (token.split(".").length !== 3) {
    throw new Error("Unauthorized (TOKEN_INVALID): Malformed JWT token");
  }
  return token;
}

/**
 * CORREÇÃO FOR-08 & Missão 3 (Vercel + Supabase):
 * Valida remotamente a sessão junto ao Supabase Auth (`supabase.auth.getUser`)
 * antes de executar operações privilegiadas que utilizam `supabaseAdmin` (`service_role`).
 * - Distingue token expirado, token inválido/revogado, conta banida e indisponibilidade de rede.
 * - Nega por padrão caso o serviço de autenticação esteja indisponível ou retorne erro.
 */
export async function verifyRemoteSupabaseSession(
  supabase: Pick<SupabaseClient<Database>, "auth">,
  expectedUserId: string,
  token?: string,
  correlationId?: string,
): Promise<{ userId: string; email: string | null; userMetadata: Record<string, unknown> }> {
  const corrId = correlationId ?? createCorrelationId();
  if (!expectedUserId || !supabase?.auth || typeof supabase.auth.getUser !== "function") {
    throw new Error("Acesso negado (TOKEN_INVALID): validação remota de sessão indisponível.");
  }

  let userData: {
    user?: {
      id?: string;
      email?: string | null;
      user_metadata?: Record<string, unknown>;
      banned_until?: string | null;
    } | null;
  } | null = null;
  let userError: { status?: number; code?: string; message?: string } | null = null;

  try {
    const res = token ? await supabase.auth.getUser(token) : await supabase.auth.getUser();
    userData = res.data as typeof userData;
    userError = (res.error ?? null) as typeof userError;
  } catch (err) {
    logStructuredAuthDiagnostic({
      operation: "auth_middleware",
      stage: "remote_session_fetch",
      correlationId: corrId,
      error: err,
      errorCode: "SUPABASE_AUTH_UNREACHABLE",
    });
    throw new Error(
      "SUPABASE_AUTH_UNREACHABLE: não foi possível validar a sessão no servidor de autenticação.",
    );
  }

  if (userError || !userData?.user?.id || userData.user.id !== expectedUserId) {
    const rawMsg = (userError?.message ?? "").toLowerCase();
    const isExpired = rawMsg.includes("expired") || rawMsg.includes("jwt expired");
    const code = isExpired ? "TOKEN_EXPIRED" : "TOKEN_INVALID";
    logStructuredAuthDiagnostic({
      operation: "auth_middleware",
      stage: "remote_session_verify",
      correlationId: corrId,
      httpStatus: userError?.status ?? 401,
      supabaseErrorCode: userError?.code ?? null,
      errorCode: code,
    });
    throw new Error(
      isExpired
        ? "Acesso negado (TOKEN_EXPIRED): sessão expirada. Faça login novamente."
        : "Acesso negado (TOKEN_INVALID): sessão inválida, expirada ou revogada.",
    );
  }

  const bannedUntil = userData.user.banned_until;
  if (typeof bannedUntil === "string" && bannedUntil.trim()) {
    const bannedMs = Date.parse(bannedUntil);
    if (Number.isFinite(bannedMs) && bannedMs > Date.now()) {
      logStructuredAuthDiagnostic({
        operation: "auth_middleware",
        stage: "remote_session_banned_check",
        correlationId: corrId,
        httpStatus: 403,
        errorCode: "USER_BANNED",
      });
      throw new Error("Acesso negado: conta de usuário suspensa ou revogada.");
    }
  }

  return {
    userId: userData.user.id,
    email: userData.user.email ?? null,
    userMetadata: (userData.user.user_metadata ?? {}) as Record<string, unknown>,
  };
}

export const requireSupabaseAuth = createMiddleware({ type: "function" }).server(
  async ({ next }) => {
    const correlationId = createCorrelationId();
    const SUPABASE_URL = (
      process.env["SUPABASE_URL"] ||
      process.env["VITE_SUPABASE_URL"] ||
      ""
    ).trim();
    const SUPABASE_ANON_KEY = (
      process.env["SUPABASE_ANON_KEY"] ||
      process.env["SUPABASE_PUBLISHABLE_KEY"] ||
      process.env["VITE_SUPABASE_ANON_KEY"] ||
      process.env["VITE_SUPABASE_PUBLISHABLE_KEY"] ||
      ""
    ).trim();

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY || isPlaceholderValue(SUPABASE_URL) || isPlaceholderValue(SUPABASE_ANON_KEY)) {
      const missing = [
        ...(!SUPABASE_URL || isPlaceholderValue(SUPABASE_URL) ? ["SUPABASE_URL"] : []),
        ...(!SUPABASE_ANON_KEY || isPlaceholderValue(SUPABASE_ANON_KEY) ? ["SUPABASE_ANON_KEY"] : []),
      ];
      const err = new Error(
        `SUPABASE_CONFIG_MISSING: Variável(is) de ambiente ausente(s) ou inválida(s) no servidor: ${missing.join(", ")}.`,
      );
      logStructuredAuthDiagnostic({
        operation: "auth_middleware",
        stage: "env_validation",
        correlationId,
        httpStatus: 500,
        error: err,
        errorCode: "SUPABASE_CONFIG_MISSING",
      });
      throw err;
    }

    const request = getRequest();
    let token: string;
    try {
      token = extractBearerTokenFromHeaders(request?.headers);
    } catch (err) {
      logStructuredAuthDiagnostic({
        operation: "auth_middleware",
        stage: "bearer_extraction",
        correlationId,
        httpStatus: 401,
        error: err,
      });
      throw err;
    }

    const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: {
        fetch: createSupabaseFetch(SUPABASE_ANON_KEY),
        headers: {
          Authorization: `Bearer ${token}`,
        },
      },
      auth: {
        storage: undefined,
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    let userId: string | undefined;
    let claims: Record<string, unknown> | undefined;

    const authAny = supabase.auth as unknown as {
      getClaims?: (jwt: string) => Promise<{
        data: { claims?: Record<string, unknown> } | null;
        error: { status?: number; code?: string; message?: string } | null;
      }>;
    };

    if (typeof authAny.getClaims === "function") {
      const claimsRes = await authAny.getClaims(token).catch(() => null);
      if (claimsRes && !claimsRes.error && claimsRes.data?.claims?.["sub"]) {
        userId = String(claimsRes.data.claims["sub"]);
        claims = claimsRes.data.claims;
      }
    }

    if (!userId) {
      let userData: { user?: { id?: string; email?: string | null; user_metadata?: Record<string, unknown> } | null } | null = null;
      let userError: { status?: number; code?: string; message?: string } | null = null;
      try {
        const res = await supabase.auth.getUser(token);
        userData = res.data;
        userError = (res.error ?? null) as typeof userError;
      } catch (err) {
        logStructuredAuthDiagnostic({
          operation: "auth_middleware",
          stage: "supabase_get_user_network",
          correlationId,
          httpStatus: 503,
          error: err,
          errorCode: "SUPABASE_AUTH_UNREACHABLE",
        });
        throw new Error(
          "SUPABASE_AUTH_UNREACHABLE: Falha de rede ao validar token no Supabase Auth.",
        );
      }

      if (userError || !userData?.user?.id) {
        const rawMsg = (userError?.message ?? "").toLowerCase();
        const isExpired = rawMsg.includes("expired") || rawMsg.includes("jwt expired");
        const code = isExpired ? "TOKEN_EXPIRED" : "TOKEN_INVALID";
        logStructuredAuthDiagnostic({
          operation: "auth_middleware",
          stage: "supabase_get_user_validate",
          correlationId,
          httpStatus: userError?.status ?? 401,
          supabaseErrorCode: userError?.code ?? null,
          errorCode: code,
        });
        throw new Error(
          isExpired
            ? "Unauthorized (TOKEN_EXPIRED): Token expirado."
            : "Unauthorized (TOKEN_INVALID): Token inválido.",
        );
      }

      userId = userData.user.id;
      claims = {
        sub: userData.user.id,
        email: userData.user.email ?? null,
        user_metadata: userData.user.user_metadata ?? {},
      };
    }

    return next({
      context: {
        supabase,
        userId,
        token,
        correlationId,
        claims: claims ?? { sub: userId },
      },
    });
  },
);
