import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";
import { logStructuredAuthDiagnostic } from "@/lib/auth-diagnostics";

function isNewSupabaseApiKey(value: string): boolean {
  return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}

function isPlaceholderValue(value: string): boolean {
  const lower = value.trim().toLowerCase();
  return (
    !lower ||
    lower.includes("seu_projeto") ||
    lower.includes("sua_chave") ||
    lower.includes("sua_service_role") ||
    lower.includes("placeholder")
  );
}

export function validateSupabaseServerConfig(
  url: string | undefined,
  serviceRoleKey: string | undefined,
): { url: string; serviceRoleKey: string } {
  const cleanUrl = (url ?? "").trim();
  const cleanKey = (serviceRoleKey ?? "").trim();

  if (!cleanUrl || !cleanKey) {
    const missing = [
      ...(!cleanUrl ? ["SUPABASE_URL"] : []),
      ...(!cleanKey ? ["SUPABASE_SERVICE_ROLE_KEY"] : []),
    ];
    throw new Error(
      `SUPABASE_CONFIG_MISSING: Variável(is) de servidor ausente(s): ${missing.join(", ")}.`,
    );
  }

  if (isPlaceholderValue(cleanUrl)) {
    throw new Error("SUPABASE_URL_INVALID: SUPABASE_URL contém valor de exemplo.");
  }

  let parsed: URL;
  try {
    parsed = new URL(cleanUrl);
  } catch {
    throw new Error("SUPABASE_URL_INVALID: SUPABASE_URL não é uma URL HTTP(S) válida.");
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new Error("SUPABASE_URL_INVALID: protocolo inválido em SUPABASE_URL.");
  }

  if (isPlaceholderValue(cleanKey)) {
    throw new Error(
      "SUPABASE_SERVER_CONFIG_INVALID: SUPABASE_SERVICE_ROLE_KEY contém valor de exemplo.",
    );
  }

  if (cleanKey.startsWith("sb_publishable_")) {
    throw new Error(
      "SUPABASE_SERVER_CONFIG_INVALID: SUPABASE_SERVICE_ROLE_KEY foi preenchida com uma chave pública (sb_publishable_). Use a chave secreta (sb_secret_ ou service_role).",
    );
  }

  return { url: cleanUrl, serviceRoleKey: cleanKey };
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );

    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }

    if (
      isNewSupabaseApiKey(supabaseKey) &&
      headers.get("Authorization") === `Bearer ${supabaseKey}`
    ) {
      headers.delete("Authorization");
    }

    headers.set("apikey", supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

function createSupabaseAdminClient() {
  const rawUrl = process.env["SUPABASE_URL"] || process.env["VITE_SUPABASE_URL"];
  const rawKey = process.env["SUPABASE_SERVICE_ROLE_KEY"];

  let config: { url: string; serviceRoleKey: string };
  try {
    config = validateSupabaseServerConfig(rawUrl, rawKey);
  } catch (err) {
    logStructuredAuthDiagnostic({
      operation: "setup_company",
      stage: "server_admin_client_init",
      error: err,
    });
    throw err;
  }

  return createClient<Database>(config.url, config.serviceRoleKey, {
    global: {
      fetch: createSupabaseFetch(config.serviceRoleKey),
    },
    auth: {
      storage: undefined,
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

let _supabaseAdmin: ReturnType<typeof createSupabaseAdminClient> | undefined;

export const supabaseAdmin = new Proxy({} as ReturnType<typeof createSupabaseAdminClient>, {
  get(_, prop, receiver) {
    if (!_supabaseAdmin) _supabaseAdmin = createSupabaseAdminClient();
    return Reflect.get(_supabaseAdmin, prop, receiver);
  },
});
