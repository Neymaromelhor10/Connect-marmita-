import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { phoneKey, processIncomingMessage } from "./interpret.server";
import { classifyWithPersistence, type FinancialCommit } from "./financial-persistence";
import type { FinancialContext, FinancialOrder } from "./financial-command";
import { brDateISO, brToday } from "./format";
import type { ExtractedBusinessEcho } from "@/routes/api/public/whatsapp/meta-webhook";
import { emitOperationalAlert } from "./operational-alerts.server";

export type IncomingWhatsAppMessage = {
  messageId: string;
  from: string;
  profileName: string | null;
  text: string;
  timestamp: string | null;
  phoneNumberId: string;
  wabaId?: string | null;
};

/**
 * Enfileira mensagens recebidas da Meta na fila durável (public.whatsapp_messages)
 * com status = 'aguardando' ANTES de retornar HTTP 200 para a Meta.
 * - Nenhuma chamada externa à IA é feita aqui (< 50ms).
 * - Mensagens já existentes em 'registrado', 'revisar', 'ignorado' ou 'processando'
 *   são ignoradas de forma idempotente (nunca reprocessadas).
 */
export async function enqueueMetaMessages(
  messages: IncomingWhatsAppMessage[],
  customSupabase?: SupabaseClient<Database>,
): Promise<{ enqueuedIds: string[]; skippedIds: string[] }> {
  const enqueuedIds: string[] = [];
  const skippedIds: string[] = [];
  if (messages.length === 0) return { enqueuedIds, skippedIds };

  const supabaseAdmin =
    customSupabase ?? (await import("@/integrations/supabase/client.server")).supabaseAdmin;

  for (const m of messages) {
    const conn = await supabaseAdmin
      .from("whatsapp_connections")
      .select("company_id, whatsapp_business_account_id")
      .eq("phone_number_id", m.phoneNumberId)
      .eq("status", "ativo")
      .maybeSingle();
    if (conn.error) throw new Error(conn.error.message);
    if (!conn.data) {
      console.warn("[whatsapp-webhook] Phone Number ID sem empresa ativa:", m.phoneNumberId);
      skippedIds.push(m.messageId);
      continue;
    }
    if (m.wabaId && m.wabaId !== conn.data.whatsapp_business_account_id) {
      console.warn("[whatsapp-webhook] WABA do evento não confere com o vínculo:", m.phoneNumberId);
      skippedIds.push(m.messageId);
      continue;
    }

    const companyId = conn.data.company_id;
    const uid = `wa:${m.messageId}`;
    const ts = Number(m.timestamp);
    const receivedAt =
      Number.isFinite(ts) && ts > 0
        ? new Date(ts * 1000).toISOString()
        : new Date().toISOString();
    const normalizedPhone = phoneKey(m.from) || m.from || "sem-telefone";

    const ins = await supabaseAdmin
      .from("whatsapp_messages")
      .insert({
        company_id: companyId,
        phone: normalizedPhone,
        direction: "inbound",
        body: m.text,
        status: "aguardando",
        message_uid: uid,
        source: "whatsapp_cloud",
        profile_name: m.profileName,
        phone_number_id: m.phoneNumberId,
        received_at: receivedAt,
      } as never)
      .select("id")
      .single();

    if (ins.data) {
      enqueuedIds.push((ins.data as { id: string }).id);
      continue;
    }

    const existing = await supabaseAdmin
      .from("whatsapp_messages")
      .select("id, status, order_id")
      .eq("company_id", companyId)
      .eq("message_uid", uid)
      .maybeSingle();

    if (!existing.data) {
      throw new Error(ins.error?.message ?? "Falha ao enfileirar mensagem na fila durável");
    }

    // Se já tem pedido ou está em revisar/registrado/ignorado/processando/aguardando, não sobrescreve
    if (existing.data.order_id || existing.data.status !== "erro") {
      skippedIds.push(existing.data.id);
      continue;
    }

    // Apenas se estava em 'erro' sem pedido e a Meta reenviou o webhook, recoloca em 'aguardando'
    await supabaseAdmin
      .from("whatsapp_messages")
      .update({ status: "aguardando", next_retry_at: new Date().toISOString() } as never)
      .eq("id", existing.data.id);
    enqueuedIds.push(existing.data.id);
  }

  return { enqueuedIds, skippedIds };
}

/**
 * Worker durável de drenagem da fila do WhatsApp.
 * - Reclama lotes via RPC `claim_whatsapp_queue_batch` (`FOR UPDATE SKIP LOCKED`)
 * - Nunca reprocessa mensagens em `revisar`, `registrado` ou `ignorado`
 * - Processa com concorrência máxima controlada (padrão: 3)
 */
export async function drainWhatsAppQueue(options?: {
  companyId?: string;
  messageId?: string;
  limit?: number;
  concurrency?: number;
  supabase?: SupabaseClient<Database>;
}): Promise<{ claimed: number; processed: number; failed: number }> {
  const supabaseAdmin =
    options?.supabase ?? (await import("@/integrations/supabase/client.server")).supabaseAdmin;
  const limit = Math.min(Math.max(1, options?.limit ?? 15), 50);
  const concurrency = Math.min(Math.max(1, options?.concurrency ?? 3), 5);

  let claimedRows: Database["public"]["Tables"]["whatsapp_messages"]["Row"][] = [];

  const maybeRpc = (
    supabaseAdmin as unknown as {
      rpc?: (
        fn: string,
        args: Record<string, unknown>,
      ) => PromiseLike<{
        data: Database["public"]["Tables"]["whatsapp_messages"]["Row"][] | null;
        error: { code?: string; message: string } | null;
      }>;
    }
  ).rpc;

  let usedRpc = false;
  if (typeof maybeRpc === "function") {
    try {
      const rpcRes = await maybeRpc.call(supabaseAdmin, "claim_whatsapp_queue_batch", {
        _batch_size: limit,
        _lock_seconds: 90,
        _company_id: options?.companyId ?? null,
        _message_id: options?.messageId ?? null,
        _limit: limit,
      });
      if (!rpcRes.error && Array.isArray(rpcRes.data)) {
        claimedRows = rpcRes.data;
        usedRpc = true;
      }
    } catch {
      // fallback abaixo para ambientes de teste mockados sem a RPC
    }
  }

  if (!usedRpc) {
    let q = supabaseAdmin
      .from("whatsapp_messages")
      .select("*")
      .is("order_id", null)
      .in("status", ["aguardando", "erro", "processando"])
      .order("created_at", { ascending: true })
      .limit(limit);
    if (options?.companyId) {
      q = q.eq("company_id", options.companyId);
    }
    if (options?.messageId) {
      q = q.eq("id", options.messageId);
    }
    const fallbackRes = await q;
    if (fallbackRes.error) throw new Error(fallbackRes.error.message);
    claimedRows = (fallbackRes.data ?? []).filter(
      (r) =>
        !r.order_id &&
        (r.status === "aguardando" || r.status === "erro" || r.status === "processando"),
    );
  }

  if (claimedRows.length === 0) {
    return { claimed: 0, processed: 0, failed: 0 };
  }

  let processed = 0;
  let failed = 0;
  let cursor = 0;

  async function workerLoop() {
    while (cursor < claimedRows.length) {
      const idx = cursor++;
      const row = claimedRows[idx];
      if (!row) continue;
      // Garantia extra em código: nunca reprocessa revisar, registrado ou ignorado
      if (row.order_id || ["revisar", "registrado", "ignorado"].includes(row.status)) {
        continue;
      }
      try {
        await processIncomingMessage(
          supabaseAdmin,
          row.company_id,
          {
            phone: row.phone === "sem-telefone" ? "" : row.phone,
            body: row.body,
            externalId: row.message_uid ?? undefined,
            messageId: row.id,
          },
          {
            source: row.source,
            profile_name: row.profile_name,
            phone_number_id: row.phone_number_id,
            received_at: row.received_at,
            attempts: row.attempts ?? 0,
          },
        );
        processed++;
      } catch (err) {
        console.error("[whatsapp-queue-worker] erro ao processar mensagem", row.id, err);
        failed++;
      }
    }
  }

  const workers = Array.from(
    { length: Math.min(concurrency, claimedRows.length) },
    () => workerLoop(),
  );
  await Promise.all(workers);

  if (failed > 0) {
    await emitOperationalAlert({
      code: "WHATSAPP_WORKER_BATCH_FAILURES",
      severity: "warning",
      title: "Falha ao processar mensagem(ns) na fila durável do WhatsApp",
      details: { claimed: claimedRows.length, processed, failed },
    });
  }

  return { claimed: claimedRows.length, processed, failed };
}

/**
 * Mantido para compatibilidade com chamadas síncronas e suítes de testes existentes:
 * persiste na fila durável e drena os itens recém-enfileirados.
 */
export async function handleMetaMessages(messages: IncomingWhatsAppMessage[]) {
  if (messages.length === 0) return;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  let failed = false;

  for (const m of messages) {
    const conn = await supabaseAdmin
      .from("whatsapp_connections")
      .select("company_id, whatsapp_business_account_id")
      .eq("phone_number_id", m.phoneNumberId)
      .eq("status", "ativo")
      .maybeSingle();
    if (conn.error) throw new Error(conn.error.message);
    if (!conn.data) {
      console.warn("[whatsapp-webhook] Phone Number ID sem empresa ativa:", m.phoneNumberId);
      continue;
    }
    if (m.wabaId && m.wabaId !== conn.data.whatsapp_business_account_id) {
      console.warn("[whatsapp-webhook] WABA do evento não confere com o vínculo:", m.phoneNumberId);
      continue;
    }
    const companyId = conn.data.company_id;
    const uid = `wa:${m.messageId}`;
    const ts = Number(m.timestamp);
    const extra = {
      source: "whatsapp_cloud",
      profile_name: m.profileName,
      phone_number_id: m.phoneNumberId,
      received_at:
        Number.isFinite(ts) && ts > 0
          ? new Date(ts * 1000).toISOString()
          : new Date().toISOString(),
    };

    let rowId: string | null = null;
    const claim = await supabaseAdmin
      .from("whatsapp_messages")
      .insert({
        company_id: companyId,
        phone: m.from || "sem-telefone",
        direction: "inbound",
        body: m.text,
        status: "processando",
        message_uid: uid,
        ...extra,
      } as never)
      .select("id")
      .single();
    if (claim.data) {
      rowId = (claim.data as { id: string }).id;
    } else {
      const existing = await supabaseAdmin
        .from("whatsapp_messages")
        .select("id, status, order_id")
        .eq("company_id", companyId)
        .eq("message_uid", uid)
        .maybeSingle();
      if (!existing.data) throw new Error(claim.error?.message ?? "Falha ao registrar mensagem");
      if (
        (existing.data.status !== "erro" && existing.data.status !== "aguardando") ||
        existing.data.order_id
      ) {
        continue;
      }
      rowId = existing.data.id;
    }

    try {
      await processIncomingMessage(
        supabaseAdmin,
        companyId,
        { phone: m.from, body: m.text, externalId: uid, messageId: rowId },
        extra,
      );
    } catch (err) {
      console.error("[whatsapp-webhook] erro na interpretação", m.messageId, err);
      await supabaseAdmin.from("whatsapp_messages").update({ status: "erro" }).eq("id", rowId);
      failed = true;
    }
  }
  if (failed) throw new Error("Uma ou mais mensagens falharam");
}

/**
 * Processa um eco comercial verificado ("OK" ou "OKK") enviado pela própria marmitaria
 * na conversa com o cliente (`to`). Usa exatamente o mesmo avaliador (`evaluateFinancialCommand`)
 * e commit transacional que o painel web.
 */
export async function processVerifiedBusinessEcho(
  supabase: SupabaseClient<Database>,
  companyId: string,
  echo: ExtractedBusinessEcho,
  now: Date = new Date(),
) {
  const commandText = echo.text;
  if (commandText !== "OK" && commandText !== "OKK") {
    return { skipped: true, reason: "COMANDO_NAO_RECONHECIDO" };
  }

  const ts = Number(echo.timestamp);
  const receivedDate =
    Number.isFinite(ts) && ts > 0 ? new Date(ts * 1000) : now;
  const receivedAt = receivedDate.toISOString();
  const today = brToday(now);
  const commandDate = brDateISO(receivedDate);
  const eventId = `echo:${echo.messageId}`;
  const targetKey = phoneKey(echo.to);

  if (!targetKey || !/^\d{10,11}$/.test(targetKey)) {
    return { skipped: true, reason: "CONTEXTO_NAO_IDENTIFICADO" };
  }

  const custRes = await supabase
    .from("customers")
    .select("id, name, phone")
    .eq("company_id", companyId);
  const customer = (custRes.data ?? []).find((c) => phoneKey(c.phone) === targetKey);
  if (!customer) {
    return { skipped: true, reason: "CONTEXTO_NAO_IDENTIFICADO" };
  }

  const convId = `wa:${companyId}:${customer.id}`;

  return classifyWithPersistence(
    {
      load: async (): Promise<FinancialContext> => {
        const rpc = await (supabase as unknown as {
          rpc: (
            fn: string,
            args: Record<string, unknown>,
          ) => PromiseLike<{ data: unknown; error: { code?: string; message: string } | null }>;
        }).rpc("financial_echo_context", {
          _company_id: companyId,
          _customer_id: customer.id,
          _event_id: eventId,
          _command: commandText,
          _received_at: receivedAt,
          _standalone: echo.standalone,
          _quoted: echo.quoted,
          _forwarded: echo.forwarded,
        });

        if (!rpc.error && rpc.data) {
          return rpc.data as FinancialContext;
        }

        const ordersRes = await supabase
          .from("orders")
          .select("*")
          .eq("company_id", companyId)
          .eq("customer_id", customer.id)
          .eq("order_date", today);

        const eventsRes = await supabase
          .from("financial_events")
          .select("event_id")
          .eq("company_id", companyId)
          .eq("event_id", eventId);

        const mappedOrders: FinancialOrder[] = (ordersRes.data ?? []).map((o) => ({
          id: o.id,
          companyId: o.company_id,
          customerId: o.customer_id,
          conversationId: convId,
          phone: o.financial_phone || targetKey,
          date: o.order_date,
          total: Number(o.total),
          state:
            o.financial_state === "aguardando_classificacao"
              ? "PENDENTE"
              : o.financial_state === "pago"
                ? "PAGO"
                : "FIADO",
          cancelled: o.delivery_status === "cancelado",
          paymentState: o.settled_by_payment ? "UNKNOWN" : "NONE",
          confirmed: o.financial_state !== "aguardando_classificacao",
        }));

        return {
          body: commandText,
          eventId,
          source: "verified_business_echo",
          actorAuthorized: true,
          provenanceVerified: true,
          standalone: echo.standalone,
          quoted: echo.quoted,
          forwarded: echo.forwarded,
          companyId,
          customerId: customer.id,
          conversationId: convId,
          phone: customer.phone,
          today,
          commandDate,
          explicitOrderId: null,
          processedEventIds: (eventsRes.data ?? []).map((e) => e.event_id),
          orders: mappedOrders,
        };
      },
      commit: async (_req, decision): Promise<FinancialCommit> => {
        const rpc = await (supabase as unknown as {
          rpc: (
            fn: string,
            args: Record<string, unknown>,
          ) => PromiseLike<{ data: unknown; error: { code?: string; message: string } | null }>;
        }).rpc("financial_classify_by_echo", {
          _company_id: companyId,
          _customer_id: customer.id,
          _order_id: decision.pedido_id,
          _event_id: eventId,
          _command: commandText,
          _received_at: receivedAt,
          _validation_allowed: decision.acao_financeira === "SOLICITAR_CLASSIFICACAO",
          _validation_reason: decision.motivo,
        });

        if (!rpc.error && rpc.data) {
          const res = rpc.data as FinancialCommit;
          if (decision.motivo === "MULTIPLOS_PEDIDOS_ELEGIVEIS") {
            await supabase.from("whatsapp_messages").upsert(
              {
                company_id: companyId,
                customer_id: customer.id,
                phone: customer.phone,
                direction: "outbound",
                body: `[Confirmação ${commandText}]: Cliente possui múltiplos pedidos hoje aguardando classificação. Confirme individualmente na tela de Pedidos.`,
                status: "revisar",
                message_uid: eventId,
                order_date: today,
                source: "whatsapp_echo",
              } as never,
              { onConflict: "company_id,message_uid" },
            );
          }
          return res;
        }

        if (rpc.error) {
          throw new Error(rpc.error.message);
        }
        throw new Error("Resposta financeira indisponível.");
      },
    },
    { orderId: "", eventId, command: commandText },
  );
}

export async function handleMetaBusinessEchoes(echoes: ExtractedBusinessEcho[]) {
  if (echoes.length === 0) return;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  for (const echo of echoes) {
    const conn = await supabaseAdmin
      .from("whatsapp_connections")
      .select("company_id, whatsapp_business_account_id")
      .eq("phone_number_id", echo.phoneNumberId)
      .eq("status", "ativo")
      .maybeSingle();
    if (conn.error) throw new Error(conn.error.message);
    if (!conn.data) continue;
    if (echo.wabaId && echo.wabaId !== conn.data.whatsapp_business_account_id) continue;

    await processVerifiedBusinessEcho(supabaseAdmin, conn.data.company_id, echo);
  }
}
