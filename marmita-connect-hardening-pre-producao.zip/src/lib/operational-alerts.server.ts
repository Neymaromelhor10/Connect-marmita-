import { timingSafeEqual } from "crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export type OperationalAlertSeverity = "info" | "warning" | "critical";

export type OperationalAlertPayload = {
  code: string;
  severity: OperationalAlertSeverity;
  title: string;
  details: Record<string, unknown>;
  timestamp?: string;
};

const alertCooldownMap = new Map<string, number>();
const DEFAULT_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutos por código de alerta

export function resetAlertCooldownsForTest() {
  alertCooldownMap.clear();
}

export async function emitOperationalAlert(
  alert: OperationalAlertPayload,
  options?: { cooldownMs?: number },
): Promise<{ emitted: boolean; webhookDelivered: boolean }> {
  const now = Date.now();
  const cooldownMs = options?.cooldownMs ?? DEFAULT_COOLDOWN_MS;
  const lastAt = alertCooldownMap.get(alert.code) ?? 0;

  if (cooldownMs > 0 && now - lastAt < cooldownMs) {
    return { emitted: false, webhookDelivered: false };
  }
  alertCooldownMap.set(alert.code, now);

  const structuredEntry = {
    level: alert.severity === "critical" ? "error" : alert.severity === "warning" ? "warn" : "info",
    type: "operational_alert",
    code: alert.code,
    title: alert.title,
    details: alert.details,
    timestamp: alert.timestamp ?? new Date(now).toISOString(),
  };

  if (alert.severity === "critical") {
    console.error(JSON.stringify(structuredEntry));
  } else if (alert.severity === "warning") {
    console.warn(JSON.stringify(structuredEntry));
  } else {
    console.info(JSON.stringify(structuredEntry));
  }

  const webhookUrl = process.env["OPERATIONAL_ALERT_WEBHOOK_URL"]?.trim();
  if (!webhookUrl) {
    return { emitted: true, webhookDelivered: false };
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5_000);
    const res = await fetch(webhookUrl, {
      method: "POST",
      signal: controller.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(structuredEntry),
    });
    clearTimeout(timer);
    return { emitted: true, webhookDelivered: res.ok };
  } catch (err) {
    console.error(
      JSON.stringify({
        level: "error",
        type: "operational_alert_webhook_error",
        code: alert.code,
        error: err instanceof Error ? err.message : String(err),
      }),
    );
    return { emitted: true, webhookDelivered: false };
  }
}

export function authenticateCronRequest(request: Request): boolean {
  const cronSecret = process.env["CRON_SECRET"]?.trim();
  if (!cronSecret) return false;

  const authHeader = request.headers.get("authorization") ?? "";
  const bearerToken = authHeader.toLowerCase().startsWith("bearer ")
    ? authHeader.slice(7).trim()
    : "";
  const customHeader = request.headers.get("x-cron-secret")?.trim() ?? "";
  const provided = bearerToken || customHeader;

  if (!provided) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(cronSecret);
  return a.length === b.length && timingSafeEqual(a, b);
}

export type QueueHealthSnapshot = {
  healthy: boolean;
  dbConnected: boolean;
  counts: {
    aguardando: number;
    processando: number;
    erro: number;
    stuckProcessing: number;
  };
  checkedAt: string;
};

export async function inspectOperationalQueueHealth(
  supabaseAdmin: SupabaseClient<Database>,
): Promise<QueueHealthSnapshot> {
  const checkedAt = new Date().toISOString();

  const ping = await supabaseAdmin.from("companies").select("id").limit(1);
  if (ping.error) {
    await emitOperationalAlert({
      code: "DB_CONNECTION_FAILURE",
      severity: "critical",
      title: "Falha de conectividade com o PostgreSQL/Supabase",
      details: { error: ping.error.message },
      timestamp: checkedAt,
    });
    return {
      healthy: false,
      dbConnected: false,
      counts: { aguardando: 0, processando: 0, erro: 0, stuckProcessing: 0 },
      checkedAt,
    };
  }

  const pendingRes = await supabaseAdmin
    .from("whatsapp_messages")
    .select("id, status, locked_until, created_at")
    .is("order_id", null)
    .in("status", ["aguardando", "processando", "erro"])
    .limit(500);

  const rows = (pendingRes.data ?? []) as {
    id: string;
    status: string;
    locked_until?: string | null;
    created_at: string;
  }[];

  const nowMs = Date.now();
  let aguardando = 0;
  let processando = 0;
  let erro = 0;
  let stuckProcessing = 0;

  for (const r of rows) {
    if (r.status === "aguardando") aguardando++;
    else if (r.status === "processando") {
      processando++;
      const lockMs = r.locked_until ? Date.parse(r.locked_until) : Date.parse(r.created_at) + 120_000;
      if (Number.isFinite(lockMs) && lockMs < nowMs) {
        stuckProcessing++;
      }
    } else if (r.status === "erro") {
      erro++;
    }
  }

  if (stuckProcessing > 0 || erro >= 5) {
    await emitOperationalAlert({
      code: "WHATSAPP_QUEUE_DEGRADED",
      severity: erro >= 10 ? "critical" : "warning",
      title: "Mensagens acumuladas em erro ou lock expirado na fila do WhatsApp",
      details: { aguardando, processando, erro, stuckProcessing },
      timestamp: checkedAt,
    });
  }

  return {
    healthy: stuckProcessing === 0 && erro < 10,
    dbConnected: true,
    counts: { aguardando, processando, erro, stuckProcessing },
    checkedAt,
  };
}
