import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import type { FinancialFields } from "./financial-state";
export {
  balanceByCustomer,
  computeDashboardSummary,
  isAwaitingClassification,
  isConfirmedOrder,
  isConfirmedUnpaid,
  isFiadoOrder,
  isPaidOnSpotOrder,
  round2,
} from "./financial-state";

export type Customer = Database["public"]["Tables"]["customers"]["Row"];
export type Order = Database["public"]["Tables"]["orders"]["Row"] & FinancialFields;
export type Payment = Database["public"]["Tables"]["payments"]["Row"];
export type Company = Database["public"]["Tables"]["companies"]["Row"];
export type WhatsMessage = Database["public"]["Tables"]["whatsapp_messages"]["Row"] & {
  orders?: {
    total: number;
    financial_state?: "aguardando_classificacao" | "pago" | "fiado" | null;
    paid?: boolean;
  } | null;
};
export type WhatsConnection = Database["public"]["Tables"]["whatsapp_connections"]["Row"];

export function useCompany() {
  return useQuery({
    queryKey: ["company"],
    queryFn: async (): Promise<Company | null> => {
      const { data, error } = await supabase.from("companies").select("*").limit(1).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function useWhatsAppConnection(companyId?: string) {
  return useQuery({
    queryKey: ["whatsapp_connection", companyId ?? "current"],
    enabled: Boolean(companyId),
    queryFn: async (): Promise<Pick<
      WhatsConnection,
      "id" | "phone_number_id" | "whatsapp_business_account_id" | "status" | "display_phone_number"
    > | null> => {
      if (!companyId) return null;
      const { data, error } = await supabase
        .from("whatsapp_connections")
        .select("id, phone_number_id, whatsapp_business_account_id, status, display_phone_number")
        .eq("company_id", companyId)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function useCustomers() {
  return useQuery({
    queryKey: ["customers"],
    queryFn: async (): Promise<Customer[]> => {
      return await fetchAll((a, b) =>
        supabase
          .from("customers")
          .select("*")
          .order("name", { ascending: true })
          .order("id", { ascending: true })
          .range(a, b),
      );
    },
  });
}

export type OrderWithCustomer = Order & { customers: Pick<Customer, "name" | "phone"> | null };

/**
 * O servidor devolve no máximo 1.000 linhas por consulta; por isso lemos em páginas
 * com ordenação estável (id desempata) até acabar, sem limite fixo que corte relatórios.
 */
const PAGE = 1000;
async function fetchAll<T>(
  page: (from: number, to: number) => PromiseLike<{ data: T[] | null; error: unknown }>,
) {
  const out: T[] = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await page(from, from + PAGE - 1);
    if (error) throw error;
    out.push(...(data ?? []));
    if (!data || data.length < PAGE) return out;
  }
}

export function useOrders() {
  return useQuery({
    queryKey: ["orders"],
    queryFn: async (): Promise<OrderWithCustomer[]> =>
      (await fetchAll((a, b) =>
        supabase
          .from("orders")
          .select("*, customers(name, phone)")
          .order("order_date", { ascending: false })
          .order("created_at", { ascending: false })
          .order("id", { ascending: false })
          .range(a, b),
      )) as OrderWithCustomer[],
  });
}

export function usePayments() {
  return useQuery({
    queryKey: ["payments"],
    queryFn: async (): Promise<(Payment & { customers: { name: string } | null })[]> => {
      return (await fetchAll((a, b) =>
        supabase
          .from("payments")
          .select("*, customers(name)")
          .order("paid_at", { ascending: false })
          .order("id", { ascending: false })
          .range(a, b),
      )) as (Payment & { customers: { name: string } | null })[];
    },
  });
}

export function useMessages() {
  return useQuery({
    queryKey: ["messages"],
    queryFn: async (): Promise<WhatsMessage[]> => {
      const { data, error } = await supabase
        .from("whatsapp_messages")
        .select("*, orders(total, financial_state, paid)")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) {
        // Fallback compatível caso financial_state ainda não esteja aplicado no banco publicado
        const fallback = await supabase
          .from("whatsapp_messages")
          .select("*, orders(total, paid)")
          .order("created_at", { ascending: false })
          .limit(100);
        if (fallback.error) throw fallback.error;
        return (fallback.data ?? []) as WhatsMessage[];
      }
      return (data ?? []) as WhatsMessage[];
    },
  });
}

export function whatsappLink(phone: string, text: string) {
  const digits = phone.replace(/\D/g, "");
  // Números brasileiros têm 10 ou 11 dígitos sem DDI; só então prefixamos o 55.
  const full = digits.length <= 11 ? `55${digits}` : digits;
  return `https://wa.me/${full}?text=${encodeURIComponent(text)}`;
}
