import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const schema = z.object({
  phoneNumberId: z.string().trim().regex(/^\d{5,32}$/),
  wabaId: z.string().trim().regex(/^\d{5,32}$/),
});

/**
 * Vincula um número do WhatsApp Cloud API à empresa do usuário logado.
 * A empresa vem SEMPRE do perfil no backend (nunca do navegador). Antes de gravar:
 * 1) a Meta confirma (leitura) que o Phone Number ID pertence ao WABA informado e que o
 *    token da plataforma tem acesso a ele; 2) o número não pode estar vinculado a outra empresa.
 * Nenhuma mensagem é enviada.
 */
export const linkWhatsAppNumber = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => schema.parse(d))
  .handler(async ({ data, context }) => {
    const profile = await context.supabase
      .from("profiles")
      .select("company_id")
      .eq("id", context.userId)
      .maybeSingle();
    const companyId = profile.data?.company_id;
    if (!companyId) throw new Error("Empresa não encontrada.");

    const token = process.env["WHATSAPP_ACCESS_TOKEN"];
    if (!token) throw new Error("Integração com a Meta não configurada.");

    const res = await fetch(
      `https://graph.facebook.com/v21.0/${data.wabaId}/phone_numbers?fields=id,display_phone_number`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    const body = (await res.json().catch(() => ({}))) as {
      data?: { id: string; display_phone_number?: string }[];
      error?: { code?: number };
    };
    if (!res.ok) {
      if (body.error?.code === 190)
        throw new Error("O token de acesso da Meta expirou. Gere um token permanente e atualize-o.");
      throw new Error("A Meta não confirmou esta conta do WhatsApp Business.");
    }
    const phone = body.data?.find((p) => p.id === data.phoneNumberId);
    if (!phone) throw new Error("Este Phone Number ID não pertence à conta do WhatsApp Business informada.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const taken = await supabaseAdmin
      .from("whatsapp_connections")
      .select("company_id")
      .eq("phone_number_id", data.phoneNumberId)
      .maybeSingle();
    if (taken.data && taken.data.company_id !== companyId)
      throw new Error("Este número já está vinculado a outra conta.");

    const row = {
      company_id: companyId,
      phone_number_id: data.phoneNumberId,
      whatsapp_business_account_id: data.wabaId,
      status: "ativo",
      verified_at: new Date().toISOString(),
      display_phone_number: phone.display_phone_number ?? null,
    };
    // Uma conexão por empresa: reconectar/trocar número atualiza a mesma linha.
    const saved = await supabaseAdmin
      .from("whatsapp_connections")
      .upsert(row, { onConflict: "company_id" })
      .select("id, phone_number_id, whatsapp_business_account_id, status")
      .single();
    if (saved.error) {
      if (saved.error.code === "23505") throw new Error("Este número já está vinculado a outra conta.");
      throw new Error("Não foi possível salvar.");
    }

    // Sincroniza flag whatsapp_connected na empresa para refletir no cabeçalho da aplicação.
    await supabaseAdmin
      .from("companies")
      .update({ whatsapp_connected: true })
      .eq("id", companyId);

    return saved.data;
  });
