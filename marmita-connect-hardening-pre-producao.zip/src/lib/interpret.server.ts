import { z } from "zod";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { brToday } from "./format";
import { evaluateFinancialCommand } from "./financial-command";
import { emitOperationalAlert } from "./operational-alerts.server";

export type MessageInput = {
  phone: string;
  body: string;
  externalId?: string | undefined;
  messageId?: string | undefined;
};

export const parsedMessageSchema = z.object({
  eh_pedido: z.boolean(),
  nome: z.string().nullable().optional().default(null),
  qtd_g: z.number().nullable().optional().default(null),
  qtd_m: z.number().nullable().optional().default(null),
  qtd_p: z.number().nullable().optional().default(null),
  data: z.string().nullable().optional().default(null),
  fiado: z.boolean().optional().default(false),
  qtd_pagar_depois: z.number().nullable().optional().default(null),
  motivo: z.string().nullable().optional().default(null),
});

export type ParsedMessage = z.infer<typeof parsedMessageSchema>;

export const GEMINI_MODEL = "gemini-2.5-flash";
const GEMINI_TIMEOUT_MS = 10_000;
const GEMINI_MAX_ATTEMPTS = 3;

export const phoneKey = (raw: string | null | undefined) => {
  const d = (raw ?? "").replace(/\D/g, "");
  return (d.length === 12 || d.length === 13) && d.startsWith("55") ? d.slice(2) : d;
};

async function sha(input: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function deterministicUuid(input: string): Promise<string> {
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(input)) {
    return input.toLowerCase();
  }
  const hex = await sha(input);
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-4${hex.slice(13, 16)}-8${hex.slice(17, 20)}-${hex.slice(20, 32)}`;
}

const norm = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();

const parseQty = (val: unknown): number | null =>
  val !== null && val !== undefined && val !== "" && Number.isFinite(Number(val))
    ? Math.max(0, Math.trunc(Number(val)))
    : null;

async function loadCompanyCustomers(supabase: SupabaseClient<Database>, companyId: string) {
  const out: { id: string; name: string; phone: string }[] = [];
  const PAGE = 1000;
  for (let from = 0; ; from += PAGE) {
    const res = await supabase
      .from("customers")
      .select("id, name, phone")
      .eq("company_id", companyId)
      .order("id", { ascending: true })
      .range(from, from + PAGE - 1);
    if (res.error) throw new Error(res.error.message);
    out.push(...(res.data ?? []));
    if (!res.data || res.data.length < PAGE) break;
  }
  return out;
}

async function lookupCustomerByPhoneFast(
  supabase: SupabaseClient<Database>,
  companyId: string,
  normalizedKey: string,
): Promise<{ id: string; name: string; phone: string } | null> {
  if (!normalizedKey) return null;
  const maybeRpc = (
    supabase as unknown as {
      rpc?: (
        fn: string,
        args: Record<string, unknown>,
      ) => PromiseLike<{
        data: { id: string; name: string; phone: string }[] | null;
        error: { code?: string; message: string } | null;
      }>;
    }
  ).rpc;

  if (typeof maybeRpc === "function") {
    try {
      const rpcRes = await maybeRpc.call(supabase, "find_customer_by_phone", {
        _company_id: companyId,
        _phone: normalizedKey,
      });
      if (!rpcRes.error && Array.isArray(rpcRes.data) && rpcRes.data.length > 0) {
        return rpcRes.data[0] ?? null;
      }
    } catch {
      // fallback para varredura em caso de ambiente de teste mockado
    }
  }
  return null;
}

function buildSystemInstruction(today: string): string {
  return (
    `Você lê mensagens de clientes de uma marmitaria brasileira e extrai APENAS cliente e quantidades do pedido. ` +
    `Hoje é ${today}. Marmitas têm três tamanhos: P (pequena), M (média) e G (grande). ` +
    `Responda SOMENTE com JSON: {"eh_pedido":bool,"nome":string|null,"qtd_g":number|null,"qtd_m":number|null,"qtd_p":number|null,"data":"YYYY-MM-DD"|null,"motivo":string|null}. ` +
    `Regras: entenda "3G", "3 grandes", "três grandes", "2M", "2 médias", "duas médias", "1P", "1 pequena", "uma pequena". ` +
    `NUNCA invente quantidades nem tamanhos: se a mensagem não disser o número ("manda umas grandes", "as de sempre") ou pedir marmita sem especificar tamanho ("manda 2 marmitas"), deixe as quantidades como null e explique em motivo. ` +
    `NUNCA decida se o pedido está pago ou fiado: ignore frases como "vou pagar agora", "coloca na conta" ou "depois eu pago", pois a confirmação financeira (OK ou OKK) é exclusiva da marmitaria. ` +
    `"nome" é o nome do CLIENTE que pede (não o do atendente a quem a mensagem é dirigida); se incerto, null. ` +
    `Saudações, dúvidas de preço, agradecimentos e avisos de pagamento têm eh_pedido=false. ` +
    `Nunca calcule valores em dinheiro.`
  );
}

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export async function callGeminiExtractOrder(
  body: string,
  today: string,
  options?: { maxAttempts?: number; baseDelayMs?: number; timeoutMs?: number },
): Promise<ParsedMessage> {
  const apiKey = process.env["GEMINI_API_KEY"];
  if (!apiKey) {
    throw new Error("IA indisponível: configure a variável GEMINI_API_KEY no servidor.");
  }

  const maxAttempts = options?.maxAttempts ?? GEMINI_MAX_ATTEMPTS;
  const baseDelayMs = options?.baseDelayMs ?? 300;
  const timeoutMs = options?.timeoutMs ?? GEMINI_TIMEOUT_MS;

  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: buildSystemInstruction(today) }],
          },
          contents: [
            {
              role: "user",
              parts: [{ text: body }],
            },
          ],
          generationConfig: {
            temperature: 0,
            responseMimeType: "application/json",
            responseSchema: {
              type: "OBJECT",
              properties: {
                eh_pedido: { type: "BOOLEAN" },
                nome: { type: "STRING", nullable: true },
                qtd_g: { type: "INTEGER", nullable: true },
                qtd_m: { type: "INTEGER", nullable: true },
                qtd_p: { type: "INTEGER", nullable: true },
                data: { type: "STRING", nullable: true },
                motivo: { type: "STRING", nullable: true },
              },
              required: ["eh_pedido"],
            },
          },
        }),
      });

      clearTimeout(timer);

      if (res.status === 429 || res.status >= 500) {
        const isRateLimit = res.status === 429;
        lastError = new Error(
          isRateLimit
            ? "Limite de requisições da API Gemini atingido. A mensagem foi salva para reprocessamento."
            : `Serviço Gemini temporariamente indisponível (HTTP ${res.status}).`,
        );
        if (attempt < maxAttempts) {
          await sleep(baseDelayMs * Math.pow(2, attempt - 1));
          continue;
        }
        throw lastError;
      }

      if (res.status === 401 || res.status === 403) {
        throw new Error("Chave GEMINI_API_KEY inválida ou sem permissão na Google AI API.");
      }

      if (!res.ok) {
        throw new Error(`Não foi possível interpretar a mensagem no Gemini (HTTP ${res.status}).`);
      }

      const payload = (await res.json()) as {
        candidates?: { content?: { parts?: { text?: string }[] } }[];
        choices?: { message?: { content?: string } }[];
      };

      const rawText =
        payload.candidates?.[0]?.content?.parts?.[0]?.text ??
        payload.choices?.[0]?.message?.content ??
        "";

      if (!rawText.trim()) {
        throw new Error("A IA retornou uma resposta vazia.");
      }

      let rawJson: unknown;
      try {
        rawJson = JSON.parse(rawText.replace(/```json|```/g, "").trim());
      } catch {
        throw new Error("A IA respondeu em formato JSON inválido.");
      }

      const validated = parsedMessageSchema.safeParse(rawJson);
      if (!validated.success) {
        throw new Error("A resposta da IA não cumpriu o contrato esperado de pedido.");
      }

      return validated.data;
    } catch (err) {
      clearTimeout(timer);
      const isAbort =
        err instanceof Error && (err.name === "AbortError" || /aborted|timeout/i.test(err.message));
      const isNetwork =
        err instanceof TypeError ||
        (err instanceof Error && /fetch|network|ECONNRESET|ETIMEDOUT/i.test(err.message));

      if ((isAbort || isNetwork) && attempt < maxAttempts) {
        lastError = isAbort
          ? new Error("Tempo limite excedido ao consultar a API Gemini.")
          : err instanceof Error
            ? err
            : new Error(String(err));
        await sleep(baseDelayMs * Math.pow(2, attempt - 1));
        continue;
      }

      if (isAbort) {
        throw new Error(
          "Tempo limite excedido ao consultar a API Gemini. A mensagem foi salva para reprocessamento.",
        );
      }
      throw err instanceof Error ? err : new Error(String(err));
    }
  }

  throw lastError ?? new Error("Falha ao consultar a API Gemini.");
}

export async function processIncomingMessage(
  supabase: SupabaseClient<Database>,
  companyId: string,
  data: MessageInput,
  extra?: Record<string, unknown>,
) {
  const rawPhoneDigits = data.phone.replace(/\D/g, "");
  const key = phoneKey(rawPhoneDigits);
  const phone = key || rawPhoneDigits;
  const body = data.body.trim();
  const today = brToday();

  const uid = data.externalId?.trim() || (await sha(`${companyId}|${phone}|${body}|${today}`));
  const dup = await supabase
    .from("whatsapp_messages")
    .select("id, status, order_id")
    .eq("company_id", companyId)
    .eq("message_uid", uid)
    .maybeSingle();

  if (dup.data && dup.data.order_id) {
    return {
      duplicate: true,
      status: dup.data.status,
      messageId: dup.data.id,
      orderId: dup.data.order_id,
      parsed: null,
    };
  }

  // Mensagens já concluídas (registrado, revisar, ignorado) NUNCA são reprocessadas automaticamente
  if (
    dup.data &&
    dup.data.status !== "erro" &&
    dup.data.status !== "processando" &&
    dup.data.status !== "aguardando"
  ) {
    return { duplicate: true, status: dup.data.status, messageId: dup.data.id, parsed: null };
  }

  let messageId = data.messageId ?? dup.data?.id ?? null;

  if (/^okk?$/i.test(body)) {
    const customerAttempt = evaluateFinancialCommand({
      body: body.toUpperCase(),
      eventId: uid,
      source: "customer",
      actorAuthorized: false,
      provenanceVerified: false,
      standalone: true,
      quoted: false,
      forwarded: false,
      companyId,
      customerId: null,
      conversationId: null,
      phone: phone || null,
      today,
      commandDate: today,
      explicitOrderId: null,
      processedEventIds: [],
      orders: [],
    });

    const ignoredRecord = {
      company_id: companyId,
      customer_id: null,
      phone: phone || "sem-telefone",
      direction: "inbound",
      body,
      parsed: {
        eh_pedido: false,
        nome: null,
        qtd_g: null,
        qtd_m: null,
        qtd_p: null,
        data: today,
        fiado: false,
        motivo: customerAttempt.motivo,
      },
      order_id: null,
      status: "ignorado" as const,
      qty_g: null,
      qty_p: null,
      fiado: false,
      order_date: today,
      ...(messageId && !data.externalId ? {} : { message_uid: uid }),
      ...(extra ?? {}),
    };

    if (messageId) {
      await supabase.from("whatsapp_messages").update(ignoredRecord).eq("id", messageId);
    } else {
      const ins = await supabase
        .from("whatsapp_messages")
        .insert(ignoredRecord)
        .select("id")
        .single();
      messageId = ins.data?.id ?? null;
    }

    return {
      duplicate: false,
      status: "ignorado" as const,
      messageId,
      orderId: null,
      customerName: null,
      parsed: {
        eh_pedido: false,
        nome: null,
        qtd_g: null,
        qtd_m: null,
        qtd_p: null,
        data: today,
        fiado: false,
        motivo: customerAttempt.motivo,
      },
    };
  }

  if (!messageId) {
    const preClaim = await supabase
      .from("whatsapp_messages")
      .insert({
        company_id: companyId,
        phone: phone || "sem-telefone",
        direction: "inbound",
        body,
        status: "processando",
        message_uid: uid,
        order_date: today,
        ...(extra ?? {}),
      } as never)
      .select("id")
      .single();
    if (preClaim.data) {
      messageId = (preClaim.data as { id: string }).id;
    }
  }

  let parsed: ParsedMessage;
  try {
    parsed = await callGeminiExtractOrder(body, today);
  } catch (aiErr) {
    const errMsg = aiErr instanceof Error ? aiErr.message : String(aiErr);
    const prevAttempts = Number(extra?.["attempts"] ?? 0) || 0;
    const nextAttempts = prevAttempts + 1;
    const backoffMs = Math.min(300_000, 15_000 * Math.pow(2, Math.max(0, nextAttempts - 1)));
    const nextRetryAt = new Date(Date.now() + backoffMs).toISOString();

    if (messageId) {
      const errUpdate = await supabase
        .from("whatsapp_messages")
        .update({
          status: "erro",
          locked_until: null,
          next_retry_at: nextRetryAt,
          last_error: errMsg,
          parsed: { eh_pedido: false, motivo: `Falha IA: ${errMsg}` },
        } as never)
        .eq("id", messageId);

      if (errUpdate.error && /locked_until|next_retry_at|last_error/i.test(errUpdate.error.message)) {
        await supabase
          .from("whatsapp_messages")
          .update({
            status: "erro",
            parsed: { eh_pedido: false, motivo: `Falha IA: ${errMsg}` },
          } as never)
          .eq("id", messageId);
      }
    }

    if (nextAttempts >= 3) {
      await emitOperationalAlert({
        code: "GEMINI_INTERPRETATION_FAILURE",
        severity: "warning",
        title: "Falhas consecutivas na interpretação Gemini",
        details: { companyId, messageId, attempts: nextAttempts, error: errMsg },
      });
    }
    throw aiErr;
  }

  const g = parseQty(parsed.qtd_g);
  const m = parseQty(parsed.qtd_m);
  const p = parseQty(parsed.qtd_p);
  const orderDate = /^\d{4}-\d{2}-\d{2}$/.test(parsed.data ?? "") ? parsed.data! : today;

  let customer: { id: string; name: string; phone?: string } | null = null;
  if (key) {
    customer = await lookupCustomerByPhoneFast(supabase, companyId, key);
  }

  let list: { id: string; name: string; phone: string }[] | null = null;
  if (!customer) {
    list = await loadCompanyCustomers(supabase, companyId);
    customer = (key ? list.find((c) => phoneKey(c.phone) === key) : undefined) ?? null;
  }

  if (!customer && !phone && list) {
    if (parsed.nome?.trim()) {
      const target = norm(parsed.nome);
      customer = list.find((c) => norm(c.name) === target) ?? null;
    }
    if (!customer) {
      const text = norm(data.body);
      const hits = list.filter((c) => {
        const n = norm(c.name);
        const first = n.split(" ")[0] ?? "";
        const escaped = first.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        return first.length >= 3 && new RegExp(`(^|\\W)${escaped}(\\W|$)`).test(text);
      });
      if (hits.length === 1) customer = hits[0] ?? null;
    }
  }
  if (!customer && phone.length >= 8 && phone.length <= 15 && parsed.eh_pedido) {
    const profileName =
      typeof extra?.["profile_name"] === "string" ? String(extra["profile_name"]).trim() : "";
    const name = profileName || parsed.nome?.trim() || phone;
    const created = await supabase
      .from("customers")
      .insert({ company_id: companyId, phone, name })
      .select("id, name, phone")
      .single();
    if (created.error) {
      customer = await lookupCustomerByPhoneFast(supabase, companyId, key);
      if (!customer) {
        const again = await loadCompanyCustomers(supabase, companyId);
        customer = again.find((c) => phoneKey(c.phone) === key) ?? null;
      }
      if (!customer) throw new Error(created.error.message);
    } else customer = created.data;
  }

  const totalQty = (g ?? 0) + (m ?? 0) + (p ?? 0);
  const hasQty = totalQty > 0;
  const needsReview = parsed.eh_pedido && (!hasQty || !customer);
  const status: "registrado" | "revisar" | "ignorado" = !parsed.eh_pedido
    ? "ignorado"
    : needsReview
      ? "revisar"
      : "registrado";

  const parsedPayload = JSON.parse(
    JSON.stringify({
      eh_pedido: Boolean(parsed.eh_pedido),
      nome: parsed.nome ?? null,
      qtd_g: g,
      qtd_m: m,
      qtd_p: p,
      data: orderDate,
      fiado: false,
      motivo: parsed.motivo ?? null,
    }),
  );

  let orderId: string | null = null;
  if (status === "registrado" && customer) {
    const custPhoneKey = phoneKey(customer.phone || phone);
    const creationEventUuid = await deterministicUuid(
      `${companyId}:wa_msg:${messageId ?? uid}`,
    );
    const maybeRpc = (
      supabase as unknown as {
        rpc?: (
          fn: string,
          args: Record<string, unknown>,
        ) => PromiseLike<{
          data: string | null;
          error: { code?: string; message: string } | null;
        }>;
      }
    ).rpc;

    if (messageId && typeof maybeRpc === "function") {
      try {
        const rpcOrder = await maybeRpc.call(supabase, "complete_whatsapp_message_order", {
          _message_id: messageId,
          _company_id: companyId,
          _customer_id: customer.id,
          _qty_p: p ?? 0,
          _qty_m: m ?? 0,
          _qty_g: g ?? 0,
          _order_date: orderDate,
          _parsed: parsedPayload,
          _creation_event: creationEventUuid,
          _phone_key: custPhoneKey || "",
          _source: "mensagem",
        });
        if (!rpcOrder.error && typeof rpcOrder.data === "string" && rpcOrder.data) {
          orderId = rpcOrder.data;
        } else if (
          rpcOrder.error &&
          rpcOrder.error.code !== "PGRST202" &&
          rpcOrder.error.code !== "42883"
        ) {
          throw new Error(rpcOrder.error.message);
        }
      } catch (err) {
        if (err instanceof Error && !/PGRST202|42883|not a function/i.test(err.message)) {
          throw err;
        }
      }
    }

    if (!orderId) {
      const convId = `wa:${companyId}:${customer.id}`;
      const baseOrderPayload = {
        company_id: companyId,
        customer_id: customer.id,
        qty_g: g ?? 0,
        qty_p: p ?? 0,
        quantity: totalQty,
        unit_price: 0,
        order_date: orderDate,
        paid: false,
        settled_by_payment: false,
        source: "mensagem",
      };
      const fullOrderPayload = {
        ...baseOrderPayload,
        qty_m: m ?? 0,
        financial_state: "aguardando_classificacao",
        financial_conversation_id: convId,
        financial_phone: custPhoneKey || null,
        financial_creation_event: creationEventUuid,
      };

      let order = await supabase
        .from("orders")
        .insert(fullOrderPayload as never)
        .select("id")
        .single();
      if (order.error && /qty_m|financial_/i.test(order.error.message)) {
        order = await supabase.from("orders").insert(baseOrderPayload).select("id").single();
      }
      if (order.error) throw new Error(order.error.message);
      orderId = order.data.id;
    }
  }

  const baseRecord = {
    company_id: companyId,
    customer_id: customer?.id ?? null,
    phone: phone || "sem-telefone",
    direction: "inbound",
    body,
    parsed: parsedPayload,
    order_id: orderId,
    status,
    qty_g: g,
    qty_p: p,
    fiado: false,
    order_date: orderDate,
    ...(messageId && !data.externalId ? {} : { message_uid: uid }),
    ...(extra ?? {}),
  };

  if (messageId) {
    let upd = await supabase
      .from("whatsapp_messages")
      .update({ ...baseRecord, qty_m: m })
      .eq("id", messageId);
    if (upd.error && /qty_m/i.test(upd.error.message)) {
      upd = await supabase.from("whatsapp_messages").update(baseRecord).eq("id", messageId);
    }
    if (upd.error) {
      if (orderId) {
        await supabase
          .from("whatsapp_messages")
          .update({ order_id: orderId, status: "registrado" })
          .eq("id", messageId);
      }
      throw new Error(upd.error.message);
    }
  } else {
    let ins = await supabase
      .from("whatsapp_messages")
      .insert({ ...baseRecord, qty_m: m })
      .select("id")
      .single();
    if (ins.error && /qty_m/i.test(ins.error.message)) {
      ins = await supabase.from("whatsapp_messages").insert(baseRecord).select("id").single();
    }
    if (ins.error) throw new Error(ins.error.message);
    messageId = ins.data.id;
  }

  return {
    duplicate: false,
    status,
    messageId,
    orderId,
    financialState: orderId ? ("aguardando_classificacao" as const) : null,
    customerName: customer?.name ?? parsed.nome ?? null,
    parsed: {
      eh_pedido: Boolean(parsed.eh_pedido),
      nome: parsed.nome ?? null,
      qtd_g: g,
      qtd_m: m,
      qtd_p: p,
      data: orderDate,
      fiado: false,
      motivo: parsed.motivo ?? null,
    },
  };
}
