import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const setupSchema = z.object({
  companyName: z.string().max(120).optional().default(""),
  fullName: z.string().max(120).optional().default(""),
});

export const setupCompany = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => setupSchema.parse(data ?? {}))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const userId = context.userId;

    const existing = await supabaseAdmin
      .from("profiles")
      .select("company_id")
      .eq("id", userId)
      .maybeSingle();
    if (existing.data?.company_id) return { companyId: existing.data.company_id };

    const claimsObj = (context.claims ?? {}) as {
      email?: string | null;
      user_metadata?: { full_name?: string; name?: string; company_name?: string };
    };
    const meta = claimsObj.user_metadata ?? {};

    const resolvedCompanyName =
      data.companyName.trim() ||
      (typeof meta.company_name === "string" ? meta.company_name.trim() : "") ||
      "Minha marmitaria";

    const resolvedFullName =
      data.fullName.trim() ||
      (typeof meta.full_name === "string" ? meta.full_name.trim() : "") ||
      (typeof meta.name === "string" ? meta.name.trim() : "") ||
      claimsObj.email ||
      "Responsável";

    const company = await supabaseAdmin
      .from("companies")
      .insert({ name: resolvedCompanyName })
      .select("id")
      .single();
    if (company.error) throw new Error(company.error.message);

    const profile = await supabaseAdmin.from("profiles").insert({
      id: userId,
      company_id: company.data.id,
      full_name: resolvedFullName,
      email: claimsObj.email ?? null,
    });
    if (profile.error) {
      await supabaseAdmin.from("companies").delete().eq("id", company.data.id);
      throw new Error(profile.error.message);
    }

    await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "admin" });

    // Registra permissão explícita de classificação financeira (compatível com migração 0010/0011)
    await supabaseAdmin
      .from("financial_permissions")
      .upsert(
        { company_id: company.data.id, user_id: userId, can_classify: true },
        { onConflict: "company_id,user_id" },
      );

    return { companyId: company.data.id };
  });

const parseSchema = z.object({
  phone: z.string().max(30).optional().default(""),
  body: z.string().min(1).max(2000),
  externalId: z.string().uuid().optional(),
  messageId: z.string().uuid().optional(),
});

export const interpretMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => parseSchema.parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const profile = await supabase
      .from("profiles")
      .select("company_id")
      .eq("id", userId)
      .maybeSingle();
    const companyId = profile.data?.company_id;
    if (!companyId) throw new Error("Empresa não encontrada.");

    const { processIncomingMessage } = await import("./interpret.server");
    return processIncomingMessage(supabase, companyId, {
      ...data,
      externalId: data.externalId ? `manual:${data.externalId}` : undefined,
    });
  });

const retrySchema = z.object({
  messageId: z.string().uuid().optional(),
});

export const retryPendingMessages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => retrySchema.parse(data ?? {}))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const profile = await supabase
      .from("profiles")
      .select("company_id")
      .eq("id", userId)
      .maybeSingle();
    const companyId = profile.data?.company_id;
    if (!companyId) throw new Error("Empresa não encontrada.");

    let query = supabase
      .from("whatsapp_messages")
      .select("id, phone, body, message_uid, order_id, status, profile_name, attempts")
      .eq("company_id", companyId)
      .is("order_id", null)
      .in("status", ["aguardando", "erro", "processando"])
      .order("created_at", { ascending: true })
      .limit(25);

    if (data.messageId) {
      query = supabase
        .from("whatsapp_messages")
        .select("id, phone, body, message_uid, order_id, status, profile_name, attempts")
        .eq("company_id", companyId)
        .eq("id", data.messageId)
        .is("order_id", null)
        .in("status", ["aguardando", "erro", "processando"]);
    }

    const pending = await query;
    if (pending.error) throw new Error(pending.error.message);

    const rows = pending.data ?? [];
    if (rows.length === 0) {
      return { total: 0, recovered: 0, failed: 0 };
    }

    const { processIncomingMessage } = await import("./interpret.server");
    let recovered = 0;
    let failed = 0;

    for (const row of rows) {
      // Garantia adicional: nunca reprocessa revisar, registrado ou ignorado
      if (row.order_id || ["revisar", "registrado", "ignorado"].includes(row.status)) {
        continue;
      }
      try {
        await processIncomingMessage(
          supabase,
          companyId,
          {
            phone: row.phone === "sem-telefone" ? "" : row.phone,
            body: row.body,
            externalId: row.message_uid ?? undefined,
            messageId: row.id,
          },
          {
            ...(row.profile_name ? { profile_name: row.profile_name } : {}),
            attempts: row.attempts ?? 0,
          },
        );
        recovered++;
      } catch (err) {
        console.error("[retryPendingMessages] falha ao reprocessar mensagem", row.id, err);
        failed++;
      }
    }

    return { total: rows.length, recovered, failed };
  });
