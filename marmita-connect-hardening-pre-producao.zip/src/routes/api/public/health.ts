import { createFileRoute } from "@tanstack/react-router";
import { inspectOperationalQueueHealth } from "@/lib/operational-alerts.server";

export const Route = createFileRoute("/api/public/health")({
  server: {
    handlers: {
      GET: async () => {
        const requiredEnv = {
          supabaseUrl: Boolean(process.env["VITE_SUPABASE_URL"] || process.env["SUPABASE_URL"]),
          supabaseServiceRole: Boolean(process.env["SUPABASE_SERVICE_ROLE_KEY"]),
          geminiApiKey: Boolean(process.env["GEMINI_API_KEY"]),
          whatsappVerifyToken: Boolean(process.env["WHATSAPP_VERIFY_TOKEN"]),
          whatsappAppSecret: Boolean(process.env["WHATSAPP_APP_SECRET"]),
        };

        try {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const queueHealth = await inspectOperationalQueueHealth(supabaseAdmin);
          const status = queueHealth.dbConnected ? 200 : 503;

          return new Response(
            JSON.stringify({
              status: queueHealth.healthy ? "ok" : queueHealth.dbConnected ? "degraded" : "down",
              dbConnected: queueHealth.dbConnected,
              queue: queueHealth.counts,
              configuredIntegrations: requiredEnv,
              checkedAt: queueHealth.checkedAt,
            }),
            {
              status,
              headers: {
                "content-type": "application/json; charset=utf-8",
                "cache-control": "no-store",
              },
            },
          );
        } catch (err) {
          return new Response(
            JSON.stringify({
              status: "down",
              dbConnected: false,
              configuredIntegrations: requiredEnv,
              error: err instanceof Error ? err.message : "Healthcheck error",
              checkedAt: new Date().toISOString(),
            }),
            {
              status: 503,
              headers: {
                "content-type": "application/json; charset=utf-8",
                "cache-control": "no-store",
              },
            },
          );
        }
      },
    },
  },
});
