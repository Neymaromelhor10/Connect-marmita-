import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Sparkles, AlertTriangle, Check, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { interpretMessage, retryPendingMessages } from "@/lib/company.functions";
import { WhatsAppConnection } from "@/components/WhatsAppConnection";
import { useMessages, useCompany, useCustomers, type WhatsMessage } from "@/lib/queries";
import { brl, fullDate, isoDay } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/whatsapp")({
  head: () => ({
    meta: [
      { title: "Mensagens · Verde&Mesa" },
      {
        name: "description",
        content:
          "Leitura de mensagens de clientes com IA Gemini: identifica marmitas P, M e G e registra o pedido aguardando confirmação OK / OKK.",
      },
      { property: "og:title", content: "Mensagens · Verde&Mesa" },
      {
        property: "og:description",
        content: "Interpretação de mensagens e registro de pedidos aguardando confirmação.",
      },
    ],
  }),
  component: Mensagens,
});

const statusLabel: Record<string, string> = {
  aguardando: "Na fila",
  registrado: "Registrado",
  revisar: "Revisar",
  ignorado: "Sem venda",
  erro: "Falha IA (pendente)",
  processando: "Processando",
};

function Mensagens() {
  const { data: messages = [], isLoading } = useMessages();
  const { data: company } = useCompany();
  const { data: customers = [] } = useCustomers();
  const qc = useQueryClient();
  const read = useServerFn(interpretMessage);
  const retryFn = useServerFn(retryPendingMessages);

  const [phone, setPhone] = useState("");
  const [body, setBody] = useState("");
  const [pasteKey, setPasteKey] = useState(() => crypto.randomUUID());
  const [loading, setLoading] = useState(false);
  const [retrying, setRetrying] = useState<string | null>(null);
  const [priceP, setPriceP] = useState<string | null>(null);
  const [priceM, setPriceM] = useState<string | null>(null);
  const [priceG, setPriceG] = useState<string | null>(null);
  const [review, setReview] = useState<{
    id: string;
    body: string;
    customerId: string;
    p: string;
    m: string;
    g: string;
    date: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!company) return;
    setPriceP((prev) => (prev === null ? String(company.price_p ?? 19) : prev));
    setPriceM((prev) =>
      prev === null ? String(company.price_m ?? company.price_p ?? 19.5) : prev,
    );
    setPriceG((prev) => (prev === null ? String(company.price_g ?? 20) : prev));
  }, [company]);

  const pending = messages.filter((m) => m.status === "revisar");
  const failedMessages = messages.filter(
    (m) =>
      (m.status === "erro" || m.status === "processando" || m.status === "aguardando") &&
      !m.order_id,
  );

  function refresh() {
    qc.invalidateQueries({ queryKey: ["messages"] });
    qc.invalidateQueries({ queryKey: ["orders"] });
    qc.invalidateQueries({ queryKey: ["customers"] });
  }

  async function savePrices() {
    if (!company) return;
    const rawP = (priceP ?? String(company.price_p ?? "")).trim().replace(",", ".");
    const rawM = (priceM ?? String(company.price_m ?? company.price_p ?? "")).trim().replace(",", ".");
    const rawG = (priceG ?? String(company.price_g ?? "")).trim().replace(",", ".");
    const p = Number(rawP);
    const m = Number(rawM);
    const g = Number(rawG);
    if (
      !rawP ||
      !rawM ||
      !rawG ||
      !Number.isFinite(p) ||
      p < 0 ||
      !Number.isFinite(m) ||
      m < 0 ||
      !Number.isFinite(g) ||
      g < 0
    ) {
      toast.error("Informe preços válidos para P, M e G.");
      return;
    }
    let { error } = await supabase
      .from("companies")
      .update({ price_p: p, price_m: m, price_g: g })
      .eq("id", company.id);
    if (error && /price_m/i.test(error.message)) {
      ({ error } = await supabase
        .from("companies")
        .update({ price_p: p, price_g: g })
        .eq("id", company.id));
    }
    if (error) {
      toast.error("Não foi possível salvar os preços.");
      return;
    }
    toast.success("Preços atualizados");
    qc.invalidateQueries({ queryKey: ["company"] });
  }

  async function run() {
    if (!body.trim()) {
      toast.error("Cole a mensagem do cliente.");
      return;
    }
    setLoading(true);
    try {
      const res = await read({
        data: { phone: phone.trim(), body: body.trim(), externalId: pasteKey },
      });
      if (res.duplicate) toast.info("Essa mensagem já foi processada antes.");
      else if (res.status === "registrado")
        toast.success(
          `Pedido registrado para ${res.customerName ?? "cliente"} — aguardando confirmação (OK / OKK)`,
        );
      else if (res.status === "revisar")
        toast.warning("Faltou informação. Mensagem enviada para revisão.");
      else toast.info("Mensagem sem venda — não registrada.");
      setBody("");
      setPasteKey(crypto.randomUUID());
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao interpretar a mensagem");
      refresh();
    } finally {
      setLoading(false);
    }
  }

  async function handleRetry(messageId?: string) {
    setRetrying(messageId ?? "all");
    try {
      const res = await retryFn({ data: messageId ? { messageId } : {} });
      if (res.recovered > 0) {
        toast.success(`${res.recovered} mensagem(ns) reprocessada(s) com sucesso!`);
      } else if (res.failed > 0) {
        toast.error("A API Gemini ainda não respondeu. A mensagem segue salva para nova tentativa.");
      } else {
        toast.info("Nenhuma mensagem pendente para reprocessar.");
      }
      refresh();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Não foi possível reprocessar agora.");
    } finally {
      setRetrying(null);
    }
  }

  async function confirmReview() {
    if (!review || !company) return;
    const p = Math.max(0, Math.trunc(Number(review.p) || 0));
    const m = Math.max(0, Math.trunc(Number(review.m) || 0));
    const g = Math.max(0, Math.trunc(Number(review.g) || 0));
    if (!review.customerId) {
      toast.error("Escolha o cliente.");
      return;
    }
    if (p + m + g < 1) {
      toast.error("Informe pelo menos uma marmita.");
      return;
    }
    setBusy(true);

    const { error } = await supabase.rpc("create_manual_or_reviewed_order", {
      _customer_id: review.customerId,
      _qty_p: p,
      _qty_m: m,
      _qty_g: g,
      _order_date: review.date,
      _financial_state: "aguardando_classificacao",
      _source: "mensagem",
      _whatsapp_message_id: review.id,
      _event_id: review.id,
    });

    if (error) {
      setBusy(false);
      toast.error(error.message || "Não foi possível registrar o pedido.");
      return;
    }

    setBusy(false);
    setReview(null);
    toast.success("Pedido registrado aguardando confirmação (OK / OKK)");
    refresh();
  }

  async function ignore(id: string) {
    await supabase.from("whatsapp_messages").update({ status: "ignorado" }).eq("id", id);
    refresh();
  }

  function messageRecordedTotal(m: WhatsMessage): number | null {
    if (m.orders && typeof m.orders.total === "number") {
      return Number(m.orders.total);
    }
    if (!company) return null;
    const pPrice = Number(company.price_p ?? 0);
    const mPrice = Number(company.price_m ?? company.price_p ?? 0);
    const gPrice = Number(company.price_g ?? 0);
    return (m.qty_p ?? 0) * pPrice + (m.qty_m ?? 0) * mPrice + (m.qty_g ?? 0) * gPrice;
  }

  function messageFinancialTag(m: WhatsMessage): string | null {
    if (m.status !== "registrado") return null;
    const st = m.orders?.financial_state;
    if (st === "aguardando_classificacao") return "Aguardando OK/OKK";
    if (st === "pago") return "OK · Pago";
    if (st === "fiado") return "OKK · Fiado";
    return m.orders?.paid ? "Pago" : m.fiado ? "Fiado" : "Aguardando OK/OKK";
  }

  return (
    <div className="space-y-5 px-4 pt-5 pb-8">
      <section className="panel p-4">
        <h1 className="font-display text-xl">Tabela de preços</h1>
        <p className="mt-1 text-[12px] text-muted-foreground">
          O valor de cada venda é calculado pelo sistema com estes preços — a IA nunca calcula
          dinheiro, e pedidos antigos mantêm o valor da data em que foram criados.
        </p>
        <div className="mt-3 grid grid-cols-3 gap-2.5">
          <div className="space-y-1.5">
            <Label htmlFor="price-p">Marmita P</Label>
            <Input
              id="price-p"
              type="number"
              step="0.01"
              min="0"
              inputMode="decimal"
              value={priceP ?? ""}
              onChange={(e) => setPriceP(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="price-m">Marmita M</Label>
            <Input
              id="price-m"
              type="number"
              step="0.01"
              min="0"
              inputMode="decimal"
              value={priceM ?? ""}
              onChange={(e) => setPriceM(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="price-g">Marmita G</Label>
            <Input
              id="price-g"
              type="number"
              step="0.01"
              min="0"
              inputMode="decimal"
              value={priceG ?? ""}
              onChange={(e) => setPriceG(e.target.value)}
            />
          </div>
        </div>
        <Button className="mt-3 w-full" variant="secondary" onClick={savePrices}>
          Salvar preços
        </Button>
      </section>

      <WhatsAppConnection companyId={company?.id} />

      <section className="panel p-4">
        <div className="flex items-center gap-2">
          <Sparkles className="size-4 text-gilt" />
          <h2 className="font-display text-lg">Ler mensagem do cliente</h2>
        </div>
        <p className="mt-1 text-[12px] text-muted-foreground">
          Cole a mensagem recebida. A IA identifica apenas cliente e quantidades (P, M e G). Todo
          pedido nasce aguardando a confirmação da marmitaria por OK (pago) ou OKK (fiado).
        </p>
        <div className="mt-3 space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="msg-phone">Telefone do cliente (opcional)</Label>
            <Input
              id="msg-phone"
              value={phone}
              placeholder="11987654321"
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="msg-body">Mensagem</Label>
            <Textarea
              id="msg-body"
              rows={3}
              value={body}
              placeholder="João, separa 3 G e 2 M pra mim."
              onChange={(e) => {
                setBody(e.target.value);
                setPasteKey(crypto.randomUUID());
              }}
            />
          </div>
          <Button className="w-full" disabled={loading} onClick={run}>
            <Sparkles className="size-4" /> {loading ? "Lendo…" : "Interpretar e registrar pedido"}
          </Button>
        </div>
      </section>

      {failedMessages.length > 0 && (
        <section className="panel border-accent/40 bg-accent/5 p-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg text-accent">
                Mensagens aguardando reprocessamento ({failedMessages.length})
              </h2>
              <p className="text-[11px] text-muted-foreground">
                Salvas com segurança durante indisponibilidade temporária da IA. Você pode
                reprocessar com a IA ou registrar manualmente.
              </p>
            </div>
            <Button
              size="sm"
              variant="secondary"
              disabled={retrying !== null}
              onClick={() => handleRetry()}
            >
              <RefreshCw className={`size-3.5 ${retrying === "all" ? "animate-spin" : ""}`} />{" "}
              Reprocessar todas
            </Button>
          </div>
          <div className="mt-3 space-y-2">
            {failedMessages.map((m) => (
              <div key={m.id} className="panel p-3">
                <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                  <span>{m.phone}</span>
                  <span>{fullDate(m.created_at)}</span>
                </div>
                <p className="mt-1 text-[13px]">{m.body}</p>
                <div className="mt-2.5 grid grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    disabled={retrying !== null}
                    onClick={() => handleRetry(m.id)}
                  >
                    <RefreshCw className={`size-3.5 ${retrying === m.id ? "animate-spin" : ""}`} />{" "}
                    Tentar IA novamente
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() =>
                      setReview({
                        id: m.id,
                        body: m.body,
                        customerId: m.customer_id ?? "",
                        p: m.qty_p != null ? String(m.qty_p) : "",
                        m: m.qty_m != null ? String(m.qty_m) : "",
                        g: m.qty_g != null ? String(m.qty_g) : "",
                        date: m.order_date ?? isoDay(),
                      })
                    }
                  >
                    Classificar manualmente
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section>
        <h2 className="font-display text-xl">
          Revisar {pending.length > 0 && <span className="text-accent">({pending.length})</span>}
        </h2>
        <div className="mt-3 space-y-2.5">
          {pending.length === 0 && (
            <p className="panel p-4 text-sm text-muted-foreground">Nada pendente de revisão.</p>
          )}
          {pending.map((m) => (
            <div key={m.id} className="panel p-3.5">
              <div className="flex items-center gap-2 text-[12px] text-accent">
                <AlertTriangle className="size-4" /> Revisão necessária
              </div>
              <p className="mt-1.5 text-[13px]">{m.body}</p>
              <div className="mt-3 grid grid-cols-2 gap-2">
                <Button
                  size="sm"
                  className="min-h-10"
                  onClick={() =>
                    setReview({
                      id: m.id,
                      body: m.body,
                      customerId: m.customer_id ?? "",
                      p: m.qty_p != null ? String(m.qty_p) : "",
                      m: m.qty_m != null ? String(m.qty_m) : "",
                      g: m.qty_g != null ? String(m.qty_g) : "",
                      date: m.order_date ?? isoDay(),
                    })
                  }
                >
                  Revisar
                </Button>
                <Button
                  size="sm"
                  className="min-h-10"
                  variant="secondary"
                  onClick={() => ignore(m.id)}
                >
                  Dispensar
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="font-display text-xl">Mensagens lidas</h2>
        <div className="mt-3 space-y-2.5">
          {isLoading && (
            <p className="panel p-4 text-sm text-muted-foreground">Carregando mensagens…</p>
          )}
          {!isLoading && messages.length === 0 && (
            <p className="panel p-4 text-sm text-muted-foreground">Nenhuma mensagem ainda.</p>
          )}
          {messages.map((m) => {
            const recordedTotal = m.status === "registrado" ? messageRecordedTotal(m) : null;
            const finTag = messageFinancialTag(m);
            return (
              <div key={m.id} className="panel p-3.5">
                <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                  <span>{m.phone}</span>
                  <span>{fullDate(m.created_at)}</span>
                </div>
                <p className="mt-1.5 text-[13px]">{m.body}</p>
                <div className="mt-2.5 flex flex-wrap gap-1.5 border-t border-border pt-2.5 text-[11px]">
                  <Tag>{statusLabel[m.status] ?? m.status}</Tag>
                  {m.qty_p != null && m.qty_p > 0 && <Tag>{m.qty_p} P</Tag>}
                  {m.qty_m != null && m.qty_m > 0 && <Tag>{m.qty_m} M</Tag>}
                  {m.qty_g != null && m.qty_g > 0 && <Tag>{m.qty_g} G</Tag>}
                  {finTag && <Tag>{finTag}</Tag>}
                  {m.order_date && <Tag>{fullDate(m.order_date + "T12:00:00")}</Tag>}
                  {recordedTotal !== null && <Tag>{brl(recordedTotal)}</Tag>}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <Dialog
        open={review !== null}
        onOpenChange={(o) => {
          if (!o) setReview(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-display">Revisar mensagem</DialogTitle>
          </DialogHeader>
          {review && (
            <div className="space-y-3">
              <p className="rounded-lg bg-secondary p-3 text-[13px]">{review.body}</p>
              <div className="space-y-1.5">
                <Label htmlFor="review-customer">Cliente</Label>
                <Select
                  value={review.customerId}
                  onValueChange={(v) => setReview({ ...review, customerId: v })}
                >
                  <SelectTrigger id="review-customer">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                <div className="space-y-1.5">
                  <Label htmlFor="review-p">Marmitas P</Label>
                  <Input
                    id="review-p"
                    type="number"
                    min={0}
                    inputMode="numeric"
                    value={review.p}
                    onChange={(e) => setReview({ ...review, p: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="review-m">Marmitas M</Label>
                  <Input
                    id="review-m"
                    type="number"
                    min={0}
                    inputMode="numeric"
                    value={review.m}
                    onChange={(e) => setReview({ ...review, m: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="review-g">Marmitas G</Label>
                  <Input
                    id="review-g"
                    type="number"
                    min={0}
                    inputMode="numeric"
                    value={review.g}
                    onChange={(e) => setReview({ ...review, g: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="review-date">Data</Label>
                <Input
                  id="review-date"
                  type="date"
                  value={review.date}
                  onChange={(e) => setReview({ ...review, date: e.target.value })}
                />
              </div>
              <p className="text-[11px] text-muted-foreground">
                O pedido será criado como <strong>Aguardando confirmação (OK / OKK)</strong> para
                ser finalizado pela marmitaria.
              </p>
              <div className="flex items-center justify-between rounded-lg bg-secondary px-3 py-2 text-sm">
                <span className="text-muted-foreground">Total estimado</span>
                <span className="font-display text-lg">
                  {brl(
                    (Number(review.p) || 0) * Number(company?.price_p ?? 0) +
                      (Number(review.m) || 0) *
                        Number(company?.price_m ?? company?.price_p ?? 0) +
                      (Number(review.g) || 0) * Number(company?.price_g ?? 0),
                  )}
                </span>
              </div>
              <Button className="w-full" disabled={busy} onClick={confirmReview}>
                <Check className="size-4" /> {busy ? "Registrando…" : "Registrar pedido"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded-full bg-secondary px-2 py-0.5 text-secondary-foreground">
      {children}
    </span>
  );
}
