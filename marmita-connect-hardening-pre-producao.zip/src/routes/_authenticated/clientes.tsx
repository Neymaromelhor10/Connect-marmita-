import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Pencil } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  useCustomers,
  useCompany,
  useOrders,
  usePayments,
  balanceByCustomer,
  type Customer,
} from "@/lib/queries";
import { phoneKey } from "@/lib/interpret.server";
import { brl, cycleLabel, statusLabel } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/clientes")({
  head: () => ({
    meta: [
      { title: "Clientes · Verde&Mesa" },
      {
        name: "description",
        content: "Cadastro de clientes da marmitaria com endereço, ciclo de pagamento e status.",
      },
      { property: "og:title", content: "Clientes · Verde&Mesa" },
      { property: "og:description", content: "Gestão de clientes e ciclos de pagamento." },
    ],
  }),
  component: Clientes,
});

type Draft = {
  id?: string;
  name: string;
  phone: string;
  address: string;
  notes: string;
  payment_cycle: Customer["payment_cycle"];
  status: Customer["status"];
};

const empty: Draft = {
  name: "",
  phone: "",
  address: "",
  notes: "",
  payment_cycle: "semanal",
  status: "em_dia",
};

function Clientes() {
  const { data: customers = [], isLoading } = useCustomers();
  const { data: orders = [] } = useOrders();
  const { data: payments = [] } = usePayments();
  const { data: company } = useCompany();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Draft>(empty);
  const balances = balanceByCustomer(orders, payments);

  async function save() {
    if (!company) return;
    const name = draft.name.trim();
    const digits = phoneKey(draft.phone);
    if (name.length < 2) {
      toast.error("Informe o nome do cliente.");
      return;
    }
    if (digits.length < 10 || digits.length > 15) {
      toast.error("Telefone inválido. Use DDD + número, ex.: 11987654321.");
      return;
    }
    const payload = {
      company_id: company.id,
      name,
      phone: digits,
      address: draft.address || null,
      notes: draft.notes || null,
      payment_cycle: draft.payment_cycle,
      status: draft.status,
    };
    const res = draft.id
      ? await supabase.from("customers").update(payload).eq("id", draft.id)
      : await supabase.from("customers").insert(payload);
    if (res.error) {
      toast.error(
        res.error.code === "23505"
          ? "Já existe um cliente com esse telefone."
          : "Não foi possível salvar o cliente. Tente novamente.",
      );
      return;
    }
    toast.success(draft.id ? "Cliente atualizado" : "Cliente cadastrado");
    setOpen(false);
    setDraft(empty);
    qc.invalidateQueries({ queryKey: ["customers"] });
  }

  return (
    <div className="space-y-4 px-4 pt-5 pb-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-xl">Clientes</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="min-h-10 px-3.5" onClick={() => setDraft(empty)}>
              <Plus className="size-4" /> Novo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-display">
                {draft.id ? "Editar cliente" : "Novo cliente"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <Field htmlFor="cust-name" label="Nome">
                <Input
                  id="cust-name"
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
              </Field>
              <Field htmlFor="cust-phone" label="Telefone">
                <Input
                  id="cust-phone"
                  inputMode="tel"
                  value={draft.phone}
                  placeholder="11987654321"
                  onChange={(e) => setDraft({ ...draft, phone: e.target.value })}
                />
              </Field>
              <Field htmlFor="cust-address" label="Endereço">
                <Input
                  id="cust-address"
                  value={draft.address}
                  onChange={(e) => setDraft({ ...draft, address: e.target.value })}
                />
              </Field>
              <Field htmlFor="cust-notes" label="Observações">
                <Textarea
                  id="cust-notes"
                  value={draft.notes}
                  onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field htmlFor="cust-cycle" label="Pagamento">
                  <Select
                    value={draft.payment_cycle}
                    onValueChange={(v) =>
                      setDraft({ ...draft, payment_cycle: v as Draft["payment_cycle"] })
                    }
                  >
                    <SelectTrigger id="cust-cycle">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(cycleLabel).map(([v, l]) => (
                        <SelectItem key={v} value={v}>
                          {l}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
                <Field htmlFor="cust-status" label="Status">
                  <Select
                    value={draft.status}
                    onValueChange={(v) => setDraft({ ...draft, status: v as Draft["status"] })}
                  >
                    <SelectTrigger id="cust-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(statusLabel).map(([v, l]) => (
                        <SelectItem key={v} value={v}>
                          {l}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </Field>
              </div>
              <Button className="w-full" onClick={save}>
                Salvar
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2.5">
        {isLoading && (
          <p className="panel p-4 text-sm text-muted-foreground">Carregando clientes…</p>
        )}
        {!isLoading && customers.length === 0 && (
          <p className="panel p-4 text-sm text-muted-foreground">
            Nenhum cliente ainda. Cadastre manualmente ou deixe o WhatsApp cadastrar sozinho.
          </p>
        )}
        {customers.map((c) => (
          <div key={c.id} className="panel p-3.5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-display text-[15px] leading-tight">{c.name}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">
                  {cycleLabel[c.payment_cycle]} · {c.phone}
                </div>
                {c.address && (
                  <div className="mt-1 truncate text-[11px] text-muted-foreground">{c.address}</div>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`rounded-full px-2.5 py-1 text-[10px] font-semibold ${
                    c.status === "atrasado"
                      ? "bg-accent/10 text-accent"
                      : c.status === "pendente"
                        ? "bg-gilt/15 text-gilt"
                        : "bg-good/10 text-good"
                  }`}
                >
                  {statusLabel[c.status]}
                </span>
                <button
                  aria-label={`Editar ${c.name}`}
                  onClick={() => {
                    setDraft({
                      id: c.id,
                      name: c.name,
                      phone: c.phone,
                      address: c.address ?? "",
                      notes: c.notes ?? "",
                      payment_cycle: c.payment_cycle,
                      status: c.status,
                    });
                    setOpen(true);
                  }}
                  className="grid size-10 place-items-center rounded-full bg-secondary text-secondary-foreground transition-colors hover:bg-secondary/80"
                >
                  <Pencil className="size-4" />
                </button>
              </div>
            </div>
            <div className="mt-3 flex items-center justify-between border-t border-border pt-2.5">
              <span className="text-[12px] text-muted-foreground">Saldo em aberto</span>
              <span className="font-display text-[15px]">{brl(balances.get(c.id) ?? 0)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Field({
  htmlFor,
  label,
  children,
}: {
  htmlFor: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={htmlFor}>{label}</Label>
      {children}
    </div>
  );
}
