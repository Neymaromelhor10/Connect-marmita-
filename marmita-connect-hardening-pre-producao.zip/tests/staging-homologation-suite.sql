-- ============================================================================
-- MARMITA CONNECT (VERDE&MESA) — SUÍTE DE HOMOLOGAÇÃO TÉCNICA EM POSTGRESQL REAL
-- ============================================================================
-- Executa validações reais no banco PostgreSQL/Supabase isolado de homologação:
--   0. Limpeza determinística dos IDs sintéticos de homologação (garantindo que
--      2 ou mais execuções consecutivas produzam resultados e somas idênticos,
--      sem conflito de triggers nem acumulação descontrolada no backup)
--   1. Verificação de Tabelas, Índices, Constraints, Triggers, RPCs (sem sobrecarga
--      ambígua em register_payment) e Permissões (anon/authenticated/service_role)
--   2. Execução sob SET LOCAL ROLE authenticated comprovando bloqueio de escrita
--      direta nas tabelas e funcionamento de todas as RPCs autorizadas
--   3. 12 Cenários Financeiros Obrigatórios (3G+2M=96, 5G OK=100, 5G OKK=100,
--      pagamento parcial 60 + 40, imutabilidade histórica de preços, idempotência,
--      cancelamento com tombstone e bloqueio de requisição atrasada,
--      rollback transacional sem auditoria e bloqueio via constraint trigger)
--   4. Fila Durável do WhatsApp (6 estados, lease/lock, expiração, revisão atômica,
--      bloqueio de reprocessamento de concluídos e isolamento entre empresas)
--   5. Anonimização LGPD (pré-validação com dívida aberta vs. anonimização completa)
-- ============================================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN CREATE ROLE anon NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN CREATE ROLE authenticated NOLOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'service_role') THEN CREATE ROLE service_role NOLOGIN BYPASSRLS; END IF;
END $$;

GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
GRANT USAGE ON SCHEMA auth TO anon, authenticated, service_role;

-- ============================================================================
-- BLOCO 0: LIMPEZA DETERMINÍSTICA PARA IDEMPOTÊNCIA EM EXECUÇÕES CONSECUTIVAS
-- ============================================================================
-- Como zz_financial_guard_order e financial_audit_immutable impedem DELETE de
-- pedidos financeiros e auditorias em operação normal, desabilitamos apenas os
-- dois triggers de bloqueio de exclusão durante a limpeza restrita aos 2 UUIDs
-- sintéticos de homologação e os reabilitamos imediatamente em seguida.
ALTER TABLE public.orders DISABLE TRIGGER zz_financial_guard_order;
ALTER TABLE public.financial_events DISABLE TRIGGER financial_audit_immutable;

UPDATE public.orders
   SET financial_last_audit_id = NULL
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.financial_events
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.payment_attempts
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.payments
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.whatsapp_messages
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.orders
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.customers
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.financial_permissions
 WHERE company_id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DELETE FROM public.user_roles
 WHERE user_id IN (
   'aaaaaaaa-0000-4000-8000-000000000011',
   'bbbbbbbb-0000-4000-8000-000000000022'
 );

DELETE FROM public.profiles
 WHERE id IN (
   'aaaaaaaa-0000-4000-8000-000000000011',
   'bbbbbbbb-0000-4000-8000-000000000022'
 );

DELETE FROM public.companies
 WHERE id IN (
   'aaaaaaaa-0000-4000-8000-000000000001',
   'bbbbbbbb-0000-4000-8000-000000000002'
 );

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'auth' AND table_name = 'identities'
  ) THEN
    DELETE FROM auth.identities
     WHERE user_id IN (
       'aaaaaaaa-0000-4000-8000-000000000011',
       'bbbbbbbb-0000-4000-8000-000000000022'
     );
  END IF;
END $$;

DELETE FROM auth.users
 WHERE id IN (
   'aaaaaaaa-0000-4000-8000-000000000011',
   'bbbbbbbb-0000-4000-8000-000000000022'
 ) OR email IN ('op.a@homolog.local', 'op.b@homolog.local');

ALTER TABLE public.financial_events ENABLE TRIGGER financial_audit_immutable;
ALTER TABLE public.orders ENABLE TRIGGER zz_financial_guard_order;

-- ============================================================================
-- BLOCO 1: AUDITORIA DE SCHEMA, ASSINATURAS RPC, TRIGGERS E PERMISSÕES
-- ============================================================================
DO $$
DECLARE
  missing_count int;
  reg_pay_overloads int;
BEGIN
  -- 1.1. Confirma existência das 11 tabelas obrigatórias
  SELECT count(*) INTO missing_count
  FROM unnest(ARRAY[
    'companies', 'profiles', 'user_roles', 'customers', 'orders',
    'payments', 'payment_attempts', 'financial_permissions',
    'financial_events', 'whatsapp_connections', 'whatsapp_messages'
  ]) AS t(name)
  WHERE NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = t.name
  );
  IF missing_count > 0 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Faltam % tabelas obrigatórias no schema public', missing_count;
  END IF;

  -- 1.2. Confirma que não há sobrecarga ambígua em public.register_payment
  SELECT count(*) INTO reg_pay_overloads
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  WHERE n.nspname = 'public' AND p.proname = 'register_payment';

  IF reg_pay_overloads <> 1 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Esperada exatamente 1 assinatura para public.register_payment, encontradas: %', reg_pay_overloads;
  END IF;

  -- 1.3. Confirma existência do Constraint Trigger DEFERRABLE INITIALLY IMMEDIATE em public.orders
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'zz_financial_require_audit_event'
      AND tgdeferrable = true
      AND tginitdeferred = false
  ) THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Constraint trigger zz_financial_require_audit_event não encontrado ou não é DEFERRABLE INITIALLY IMMEDIATE';
  END IF;

  -- 1.4. Confirma que authenticated NÃO possui INSERT, UPDATE ou DELETE em orders, payments e financial_events
  IF has_table_privilege('authenticated', 'public.orders', 'INSERT')
     OR has_table_privilege('authenticated', 'public.orders', 'UPDATE')
     OR has_table_privilege('authenticated', 'public.orders', 'DELETE')
     OR has_table_privilege('authenticated', 'public.payments', 'INSERT')
     OR has_table_privilege('authenticated', 'public.payments', 'UPDATE')
     OR has_table_privilege('authenticated', 'public.payments', 'DELETE')
     OR has_table_privilege('authenticated', 'public.financial_events', 'INSERT')
     OR has_table_privilege('authenticated', 'public.financial_events', 'UPDATE')
     OR has_table_privilege('authenticated', 'public.financial_events', 'DELETE') THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Role authenticated ainda possui privilégios de escrita direta em tabelas financeiras!';
  END IF;

  -- 1.5. Confirma que authenticated NÃO pode executar financial_classify_by_echo nem claim_whatsapp_queue_batch
  IF has_function_privilege(
       'authenticated',
       'public.financial_classify_by_echo(uuid, uuid, uuid, text, text, timestamptz, boolean, text)',
       'EXECUTE'
     ) THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Role authenticated não pode ter EXECUTE em financial_classify_by_echo';
  END IF;

  IF has_function_privilege(
       'authenticated',
       'public.claim_whatsapp_queue_batch(integer, integer, uuid, uuid, integer)',
       'EXECUTE'
     ) THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Role authenticated não pode ter EXECUTE em claim_whatsapp_queue_batch';
  END IF;

  RAISE NOTICE '[OK BLOCO 1] Schema, assinatura única de register_payment, triggers e permissões validados.';
END $$;

-- ============================================================================
-- BLOCO 2: PREPARAÇÃO DE USUÁRIOS AUTH.USERS E EMPRESAS ISOLADAS (A e B)
-- ============================================================================
DO $$
DECLARE
  v_comp_a uuid := 'aaaaaaaa-0000-4000-8000-000000000001';
  v_comp_b uuid := 'bbbbbbbb-0000-4000-8000-000000000002';
  v_user_a uuid := 'aaaaaaaa-0000-4000-8000-000000000011';
  v_user_b uuid := 'bbbbbbbb-0000-4000-8000-000000000022';
  v_cust_a uuid := 'aaaaaaaa-0000-4000-8000-000000000111';
  v_cust_a_lgpd uuid := 'aaaaaaaa-0000-4000-8000-000000000112';
  v_cust_b uuid := 'bbbbbbbb-0000-4000-8000-000000000222';
BEGIN
  INSERT INTO auth.users(id, email, encrypted_password, raw_user_meta_data, created_at)
  VALUES
    (v_user_a, 'op.a@homolog.local', public.crypt('SenhaHomolog123!', public.gen_salt('bf')), '{"full_name":"Operador A"}'::jsonb, now()),
    (v_user_b, 'op.b@homolog.local', public.crypt('SenhaHomolog123!', public.gen_salt('bf')), '{"full_name":"Operador B"}'::jsonb, now());

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'auth' AND table_name = 'users' AND column_name = 'instance_id'
  ) THEN
    UPDATE auth.users
       SET instance_id = '00000000-0000-0000-0000-000000000000'::uuid,
           aud = 'authenticated',
           role = 'authenticated',
           email_confirmed_at = now(),
           raw_app_meta_data = '{"provider":"email","providers":["email"]}'::jsonb,
           updated_at = now(),
           confirmation_token = '',
           recovery_token = '',
           email_change_token_new = '',
           email_change = ''
     WHERE id IN (v_user_a, v_user_b);
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'auth' AND table_name = 'users' AND column_name = 'phone_change'
  ) THEN
    EXECUTE $u$
      UPDATE auth.users
         SET phone_change = '',
             phone_change_token = '',
             email_change_token_current = '',
             email_change_confirm_status = 0,
             reauthentication_token = '',
             is_sso_user = false,
             is_anonymous = false
       WHERE email IN ('op.a@homolog.local', 'op.b@homolog.local')
    $u$;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'auth' AND table_name = 'identities'
  ) THEN
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema = 'auth' AND table_name = 'identities'
        AND column_name = 'id' AND data_type = 'uuid'
    ) THEN
      INSERT INTO auth.identities(id, provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
      VALUES
        (v_user_a, v_user_a::text, v_user_a, jsonb_build_object('sub', v_user_a::text, 'email', 'op.a@homolog.local', 'email_verified', true, 'phone_verified', false), 'email', now(), now(), now()),
        (v_user_b, v_user_b::text, v_user_b, jsonb_build_object('sub', v_user_b::text, 'email', 'op.b@homolog.local', 'email_verified', true, 'phone_verified', false), 'email', now(), now(), now())
      ON CONFLICT DO NOTHING;
    ELSE
      INSERT INTO auth.identities(id, provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
      VALUES
        (v_user_a::text, v_user_a::text, v_user_a, jsonb_build_object('sub', v_user_a::text, 'email', 'op.a@homolog.local', 'email_verified', true, 'phone_verified', false), 'email', now(), now(), now()),
        (v_user_b::text, v_user_b::text, v_user_b, jsonb_build_object('sub', v_user_b::text, 'email', 'op.b@homolog.local', 'email_verified', true, 'phone_verified', false), 'email', now(), now(), now())
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;

  INSERT INTO public.companies(id, name, price_g, price_m, price_p)
  VALUES
    (v_comp_a, 'Marmitaria Homologação A', 20.00, 18.00, 16.00),
    (v_comp_b, 'Marmitaria Homologação B', 22.00, 20.00, 18.00);

  INSERT INTO public.profiles(id, company_id, full_name, email)
  VALUES
    (v_user_a, v_comp_a, 'Operador A', 'op.a@homolog.local'),
    (v_user_b, v_comp_b, 'Operador B', 'op.b@homolog.local');

  INSERT INTO public.user_roles(user_id, role)
  VALUES
    (v_user_a, 'admin'),
    (v_user_b, 'admin');

  INSERT INTO public.financial_permissions(company_id, user_id, can_classify)
  VALUES
    (v_comp_a, v_user_a, true),
    (v_comp_b, v_user_b, true);

  INSERT INTO public.customers(id, company_id, name, phone, address, notes)
  VALUES
    (v_cust_a, v_comp_a, 'Cliente Principal A', '+55 (11) 98888-7777', 'Rua das Flores, 100', 'Sem cebola'),
    (v_cust_a_lgpd, v_comp_a, 'Cliente LGPD A', '5511988886666', 'Rua das Palmeiras, 50', 'Entrega portaria'),
    (v_cust_b, v_comp_b, 'Cliente Principal B', '(21) 97777-6666', 'Av. Atlântica, 200', NULL);

  IF (SELECT phone FROM public.customers WHERE id = v_cust_a) <> '11988887777'
     OR (SELECT phone FROM public.customers WHERE id = v_cust_a_lgpd) <> '11988886666' THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Normalização automática de telefone falhou!';
  END IF;
END $$;

-- ============================================================================
-- BLOCO 3: EXECUÇÃO COMO ROLE AUTHENTICATED (TESTES FINANCEIROS E ISOLAMENTO)
-- ============================================================================
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-4000-8000-000000000011', true);
SELECT set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-4000-8000-000000000011","role":"authenticated"}', true);

-- 3.1. Confirma que authenticated é bloqueado ao tentar INSERT direto em public.orders (com SAVEPOINT)
SAVEPOINT sp_direct_order_insert;
DO $$
BEGIN
  INSERT INTO public.orders(company_id, customer_id, quantity, unit_price)
  VALUES ('aaaaaaaa-0000-4000-8000-000000000001', 'aaaaaaaa-0000-4000-8000-000000000111', 1, 20);
  RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Role authenticated conseguiu fazer INSERT direto em public.orders!';
EXCEPTION
  WHEN insufficient_privilege THEN
    RAISE NOTICE '[OK] Role authenticated bloqueada em INSERT direto em public.orders (42501).';
END $$;
ROLLBACK TO SAVEPOINT sp_direct_order_insert;

-- 3.2. Executa os cenários financeiros via RPCs autorizadas como authenticated
DO $$
DECLARE
  v_comp_a uuid := 'aaaaaaaa-0000-4000-8000-000000000001';
  v_cust_a uuid := 'aaaaaaaa-0000-4000-8000-000000000111';
  v_cust_a_lgpd uuid := 'aaaaaaaa-0000-4000-8000-000000000112';

  v_ord_96 jsonb;
  v_ord_100_paid jsonb;
  v_ord_100_fiado jsonb;
  v_ord_100_fiado_id uuid;
  v_ord_lgpd jsonb;
  v_pay_60_id uuid;
  v_pay_40_id uuid;
  v_pay_dup_id uuid;
  v_pay_count int;
  v_pay_sum numeric;
  v_cust_status public.customer_status;

  v_idem_key_1 text := 'homolog-pay-key-1';
  v_idem_key_cancel text := 'homolog-pay-key-cancel';
  v_rec_check jsonb;
  v_rec_cancel jsonb;
  v_lgpd_diag jsonb;
  v_lgpd_res jsonb;
BEGIN
  -- Cenário 1: 3 marmitas G (R$ 20) + 2 M (R$ 18) = R$ 96,00 (aguardando_classificacao)
  v_ord_96 := public.create_manual_or_reviewed_order(
    _customer_id => v_cust_a,
    _qty_p => 0,
    _qty_m => 2,
    _qty_g => 3,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _financial_state => 'aguardando_classificacao',
    _source => 'manual',
    _event_id => 'aaaaaaaa-0000-4000-8000-000000001001'::uuid
  );

  IF (v_ord_96->>'total')::numeric <> 96.00
     OR (v_ord_96->>'financial_state') <> 'aguardando_classificacao'
     OR (v_ord_96->>'paid')::boolean <> false THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Cálculo de 3G + 2M divergiu de R$ 96,00: %', v_ord_96;
  END IF;

  -- Cenário 2: 5 G pagos na hora (OK) = R$ 100,00, sem gerar dívida
  v_ord_100_paid := public.create_manual_or_reviewed_order(
    _customer_id => v_cust_a,
    _qty_p => 0,
    _qty_m => 0,
    _qty_g => 5,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _financial_state => 'pago',
    _source => 'manual',
    _event_id => 'aaaaaaaa-0000-4000-8000-000000001002'::uuid
  );

  IF (v_ord_100_paid->>'total')::numeric <> 100.00
     OR (v_ord_100_paid->>'financial_state') <> 'pago'
     OR (v_ord_100_paid->>'paid')::boolean <> true
     OR (v_ord_100_paid->>'financial_last_audit_id') IS NULL THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Pedido de 5G pago (R$ 100,00) inválido: %', v_ord_100_paid;
  END IF;

  v_lgpd_diag := public.lgpd_inspect_customer(v_cust_a);
  IF (v_lgpd_diag->>'open_debt_amount')::numeric <> 0.00 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Pedido pago ou pendente gerou dívida indevida: %', v_lgpd_diag;
  END IF;

  -- Cenário 3: 5 G para pagar depois (OKK) = R$ 100,00 em Contas a Receber
  v_ord_100_fiado := public.create_manual_or_reviewed_order(
    _customer_id => v_cust_a,
    _qty_p => 0,
    _qty_m => 0,
    _qty_g => 5,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _financial_state => 'fiado',
    _source => 'manual',
    _event_id => 'aaaaaaaa-0000-4000-8000-000000001003'::uuid
  );
  v_ord_100_fiado_id := (v_ord_100_fiado->>'id')::uuid;

  IF (v_ord_100_fiado->>'total')::numeric <> 100.00
     OR (v_ord_100_fiado->>'financial_state') <> 'fiado'
     OR (v_ord_100_fiado->>'paid')::boolean <> false THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Pedido 5G fiado inválido: %', v_ord_100_fiado;
  END IF;

  -- Enquanto houver dívida em aberto (R$ 100,00), anonimização completa deve ser bloqueada
  BEGIN
    PERFORM public.lgpd_anonymize_customer_pii(
      _customer_id => v_cust_a,
      _scope => 'anonimizacao_completa',
      _confirm_token => 'LGPD_CONFIRM_' || v_cust_a::text,
      _protocol => 'HOMOLOG-BLOCK-DEBT'
    );
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Permitiu anonimização completa de cliente com dívida em aberto!';
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLERRM NOT LIKE '%Anonimização completa bloqueada%' THEN
        RAISE;
      END IF;
  END;

  -- Cenário 4: Pagamento parcial de R$ 60,00 em dívida de R$ 100,00
  PERFORM public.begin_payment_attempt(v_cust_a, 60.00, v_idem_key_1, 'pix', 'Parcela 1');
  v_pay_60_id := public.register_payment(v_cust_a, 60.00, 'pix', 'Parcela 1', v_idem_key_1);

  -- Cenário 5: Bloqueio de pagamento duplicado com a mesma chave
  v_pay_dup_id := public.register_payment(v_cust_a, 60.00, 'pix', 'Parcela 1', v_idem_key_1);
  IF v_pay_dup_id <> v_pay_60_id THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Idempotência falhou: criou segundo pagamento para a mesma chave!';
  END IF;

  v_lgpd_diag := public.lgpd_inspect_customer(v_cust_a);
  IF (v_lgpd_diag->>'open_debt_amount')::numeric <> 40.00 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Saldo devedor após pagamento parcial de R$ 60 deveria ser R$ 40,00, obtido: %', v_lgpd_diag;
  END IF;

  -- Cenário 6: Cancelamento explícito de tentativa (Tombstone) e bloqueio de requisição atrasada
  v_rec_check := public.reconcile_payment_attempt(v_idem_key_cancel, 'check', v_cust_a, 35.00);
  IF (v_rec_check->>'can_release_new_key')::boolean <> false THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] check com found:false liberou nova chave indevidamente!';
  END IF;

  v_rec_cancel := public.reconcile_payment_attempt(v_idem_key_cancel, 'cancel', v_cust_a, 35.00);
  IF (v_rec_cancel->>'can_release_new_key')::boolean <> true OR (v_rec_cancel->>'status') <> 'cancelled' THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Cancelamento explícito não gerou tombstone cancelled: %', v_rec_cancel;
  END IF;

  BEGIN
    PERFORM public.register_payment(v_cust_a, 35.00, 'pix', 'Pacote atrasado', v_idem_key_cancel);
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Requisição antiga atrasada conseguiu registrar pagamento após cancelamento!';
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLERRM NOT LIKE '%cancelada%' THEN
        RAISE;
      END IF;
  END;

  -- Cenário 7: Pagamento posterior dos R$ 40,00 restantes -> quita o pedido de R$ 100,00 via FIFO
  v_pay_40_id := public.register_payment(v_cust_a, 40.00, 'dinheiro', 'Parcela final', 'homolog-pay-key-2');

  IF (SELECT paid AND settled_by_payment FROM public.orders WHERE id = v_ord_100_fiado_id) <> true THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Pedido de R$ 100,00 não foi quitado via FIFO após completar R$ 60 + R$ 40!';
  END IF;

  SELECT count(*)::int, coalesce(sum(amount), 0) INTO v_pay_count, v_pay_sum
  FROM public.payments
  WHERE company_id = v_comp_a AND customer_id = v_cust_a;

  IF v_pay_count <> 2 OR v_pay_sum <> 100.00 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Histórico de pagamentos incorreto: count=%, sum=%', v_pay_count, v_pay_sum;
  END IF;

  SELECT status INTO v_cust_status FROM public.customers WHERE id = v_cust_a;
  IF v_cust_status <> 'em_dia' THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Status do cliente deveria ser em_dia após quitar dívida, obtido: %', v_cust_status;
  END IF;

  -- Cenário 8: Alteração posterior dos preços NÃO modifica pedidos antigos
  UPDATE public.companies SET price_g = 35.00, price_m = 30.00, price_p = 25.00 WHERE id = v_comp_a;

  PERFORM public.financial_classify_order(
    _order_id => (v_ord_96->>'id')::uuid,
    _event_id => 'aaaaaaaa-0000-4000-8000-000000002001'::uuid,
    _command => 'OK',
    _received_at => clock_timestamp(),
    _validation_allowed => true,
    _validation_reason => 'CONFIRMACAO_VALIDADA'
  );

  IF (SELECT total FROM public.orders WHERE id = (v_ord_96->>'id')::uuid) <> 96.00
     OR (SELECT total FROM public.orders WHERE id = v_ord_100_fiado_id) <> 100.00 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Alteração de preços da empresa modificou o valor de pedidos históricos!';
  END IF;

  UPDATE public.companies SET price_g = 20.00, price_m = 18.00, price_p = 16.00 WHERE id = v_comp_a;

  -- Cenário 9: Cliente separado para teste de anonimização completa LGPD (com pedido pago de R$ 20,00)
  v_ord_lgpd := public.create_manual_or_reviewed_order(
    _customer_id => v_cust_a_lgpd,
    _qty_p => 0,
    _qty_m => 0,
    _qty_g => 1,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _financial_state => 'pago',
    _source => 'manual',
    _event_id => 'aaaaaaaa-0000-4000-8000-000000001004'::uuid
  );

  v_lgpd_res := public.lgpd_anonymize_customer_pii(
    _customer_id => v_cust_a_lgpd,
    _scope => 'anonimizacao_completa',
    _confirm_token => 'LGPD_CONFIRM_' || v_cust_a_lgpd::text,
    _protocol => 'HOMOLOG-LGPD-001'
  );

  IF (SELECT name FROM public.customers WHERE id = v_cust_a_lgpd) NOT LIKE 'Titular Anonimizado #%'
     OR (SELECT address FROM public.customers WHERE id = v_cust_a_lgpd) IS NOT NULL
     OR (SELECT notes FROM public.customers WHERE id = v_cust_a_lgpd) IS NOT NULL
     OR EXISTS (SELECT 1 FROM public.financial_events WHERE customer_id = v_cust_a_lgpd AND phone IS NOT NULL) THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Anonimização completa LGPD deixou resíduos de PII!';
  END IF;
END $$;

-- 3.3. Isolamento Multi-Empresa: Operador B não enxerga nem opera registros da Empresa A
SELECT set_config('request.jwt.claim.sub', 'bbbbbbbb-0000-4000-8000-000000000022', true);
SELECT set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-4000-8000-000000000022","role":"authenticated"}', true);

DO $$
DECLARE
  visible_orders_a int;
BEGIN
  SELECT count(*)::int INTO visible_orders_a
  FROM public.orders
  WHERE company_id = 'aaaaaaaa-0000-4000-8000-000000000001';

  IF visible_orders_a <> 0 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] RLS falhou: Operador B visualizou % pedidos da Empresa A!', visible_orders_a;
  END IF;

  BEGIN
    PERFORM public.lgpd_inspect_customer('aaaaaaaa-0000-4000-8000-000000000111');
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Operador B conseguiu inspecionar cliente da Empresa A!';
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLERRM NOT LIKE '%Cliente não encontrado%' THEN
        RAISE;
      END IF;
  END;
END $$;

RESET ROLE;

-- ============================================================================
-- BLOCO 4: TESTE DE ROLLBACK DO CONSTRAINT TRIGGER E FILA WHATSAPP (SERVICE_ROLE)
-- ============================================================================
SAVEPOINT sp_privileged_without_audit;
DO $$
BEGIN
  INSERT INTO public.orders(
    company_id, customer_id, qty_p, qty_m, qty_g, quantity, unit_price,
    order_date, paid, settled_by_payment, source, financial_state
  )
  VALUES (
    'aaaaaaaa-0000-4000-8000-000000000001',
    'aaaaaaaa-0000-4000-8000-000000000111',
    0, 0, 2, 2, 20,
    (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    true, false, 'manual', 'pago'
  );
  RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Permitiu inserir pedido classificado sem evento em financial_events!';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLERRM NOT LIKE '%Violação de integridade financeira%' THEN
      RAISE;
    END IF;
    RAISE NOTICE '[OK] Constraint trigger bloqueou INSERT privilegiado sem evento em financial_events.';
END $$;
ROLLBACK TO SAVEPOINT sp_privileged_without_audit;

DO $$
DECLARE
  v_comp_a uuid := 'aaaaaaaa-0000-4000-8000-000000000001';
  v_cust_a uuid := 'aaaaaaaa-0000-4000-8000-000000000111';
  v_msg_1 uuid := 'aaaaaaaa-0000-4000-8000-000000003001';
  v_msg_review uuid := 'aaaaaaaa-0000-4000-8000-000000003002';
  v_claimed_count int;
  v_completed_ord_id uuid;
  v_completed_ord_id_2 uuid;
  v_reviewed_ord jsonb;
BEGIN
  PERFORM set_config('request.jwt.claim.sub', 'aaaaaaaa-0000-4000-8000-000000000011', true);
  PERFORM set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-4000-8000-000000000011","role":"authenticated"}', true);

  INSERT INTO public.whatsapp_messages(id, company_id, phone, direction, body, status, message_uid, source)
  VALUES
    (v_msg_1, v_comp_a, '11988887777', 'inbound', 'Quero 2 G e 1 P', 'aguardando', 'wa:homolog-1', 'whatsapp_cloud'),
    (v_msg_review, v_comp_a, '11988887777', 'inbound', 'Manda as de sempre', 'revisar', 'wa:homolog-rev', 'whatsapp_cloud');

  SELECT count(*)::int INTO v_claimed_count
  FROM public.claim_whatsapp_queue_batch(_batch_size => 10, _lock_seconds => 60, _company_id => v_comp_a);

  IF v_claimed_count <> 1 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] claim_whatsapp_queue_batch deveria reclamar 1 mensagem, reclamou: %', v_claimed_count;
  END IF;

  SELECT count(*)::int INTO v_claimed_count
  FROM public.claim_whatsapp_queue_batch(_batch_size => 10, _lock_seconds => 60, _company_id => v_comp_a);

  IF v_claimed_count <> 0 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Segunda instância reclamou mensagem com lease ativo!';
  END IF;

  UPDATE public.whatsapp_messages SET locked_until = clock_timestamp() - interval '10 seconds' WHERE id = v_msg_1;

  SELECT count(*)::int INTO v_claimed_count
  FROM public.claim_whatsapp_queue_batch(_batch_size => 10, _lock_seconds => 60, _company_id => v_comp_a);

  IF v_claimed_count <> 1 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] Mensagem com lease expirado não foi recuperada pela fila!';
  END IF;

  v_completed_ord_id := public.complete_whatsapp_message_order(
    _message_id => v_msg_1,
    _company_id => v_comp_a,
    _customer_id => v_cust_a,
    _qty_p => 1,
    _qty_m => 0,
    _qty_g => 2,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _parsed => '{"eh_pedido":true,"qtd_g":2,"qtd_m":0,"qtd_p":1}'::jsonb
  );

  v_completed_ord_id_2 := public.complete_whatsapp_message_order(
    _message_id => v_msg_1,
    _company_id => v_comp_a,
    _customer_id => v_cust_a,
    _qty_p => 1,
    _qty_m => 0,
    _qty_g => 2,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _parsed => '{"eh_pedido":true,"qtd_g":2,"qtd_m":0,"qtd_p":1}'::jsonb
  );

  IF v_completed_ord_id IS NULL OR v_completed_ord_id <> v_completed_ord_id_2 THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] complete_whatsapp_message_order não manteve idempotência!';
  END IF;

  v_reviewed_ord := public.create_manual_or_reviewed_order(
    _customer_id => v_cust_a,
    _qty_p => 0,
    _qty_m => 1,
    _qty_g => 1,
    _order_date => (clock_timestamp() AT TIME ZONE 'America/Sao_Paulo')::date,
    _financial_state => 'aguardando_classificacao',
    _source => 'mensagem',
    _event_id => v_msg_review,
    _whatsapp_message_id => v_msg_review
  );

  IF (SELECT status FROM public.whatsapp_messages WHERE id = v_msg_review) <> 'registrado'
     OR (SELECT order_id FROM public.whatsapp_messages WHERE id = v_msg_review) <> (v_reviewed_ord->>'id')::uuid THEN
    RAISE EXCEPTION '[FALHA HOMOLOGAÇÃO] create_manual_or_reviewed_order não atualizou atomicamente a mensagem revisada!';
  END IF;

  RAISE NOTICE '[OK BLOCO 4] Fila durável, expiração de lease, idempotência e revisão manual atômica aprovadas.';
END $$;

COMMIT;
