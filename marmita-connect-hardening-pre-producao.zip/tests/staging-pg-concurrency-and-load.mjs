import { performance } from "node:perf_hooks";
import { randomUUID } from "node:crypto";
import assert from "node:assert";

/**
 * Executa testes reais de concorrência paralela (múltiplas conexões simultâneas no PostgreSQL)
 * e carga de 5, 10, 100, 500, 1.000 e 5.000 mensagens no banco de homologação (STAGING_DATABASE_URL).
 * Toda limpeza de dados sintéticos ocorre dentro de transação segura (sql.begin), garantindo que
 * os triggers zz_financial_guard_order e financial_audit_immutable sejam sempre restaurados
 * automaticamente pelo PostgreSQL mesmo em caso de falha.
 */

const stagingUrl = process.env["STAGING_DATABASE_URL"];
if (!stagingUrl) {
  console.error("[ERRO] Defina STAGING_DATABASE_URL para executar os testes reais de concorrência e carga no PostgreSQL.");
  process.exit(1);
}

const { default: postgres } = await import("postgres");
const sql = postgres(stagingUrl, { max: 12, onnotice: () => {} });

const compId = randomUUID();
const userId = randomUUID();
const custId = randomUUID();
const today = new Date().toISOString().slice(0, 10);

async function asAuthenticated(uid, fn) {
  return sql.begin(async (tx) => {
    await tx`SET LOCAL ROLE authenticated`;
    await tx`SELECT set_config('request.jwt.claim.sub', ${uid}, true)`;
    await tx`SELECT set_config('request.jwt.claims', ${JSON.stringify({ sub: uid, role: "authenticated" })}, true)`;
    return fn(tx);
  });
}

async function cleanupSyntheticCompanyAtomic(targetCompanyId, targetUserId = null) {
  await sql.begin(async (tx) => {
    await tx`ALTER TABLE public.orders DISABLE TRIGGER zz_financial_guard_order`;
    await tx`ALTER TABLE public.financial_events DISABLE TRIGGER financial_audit_immutable`;

    await tx`UPDATE public.orders SET financial_last_audit_id = NULL WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.financial_events WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.payment_attempts WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.payments WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.whatsapp_messages WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.orders WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.customers WHERE company_id = ${targetCompanyId}`;
    await tx`DELETE FROM public.financial_permissions WHERE company_id = ${targetCompanyId}`;
    if (targetUserId) {
      await tx`DELETE FROM public.user_roles WHERE user_id = ${targetUserId}`;
      await tx`DELETE FROM public.profiles WHERE id = ${targetUserId}`;
    }
    await tx`DELETE FROM public.companies WHERE id = ${targetCompanyId}`;
    if (targetUserId) {
      await tx`DELETE FROM auth.users WHERE id = ${targetUserId}`;
    }

    await tx`ALTER TABLE public.financial_events ENABLE TRIGGER financial_audit_immutable`;
    await tx`ALTER TABLE public.orders ENABLE TRIGGER zz_financial_guard_order`;
  });
}

try {
  console.log("=== [1/5] Preparando empresa isolada para benchmark de concorrência no PostgreSQL ===");
  await sql`
    INSERT INTO auth.users(id, email, encrypted_password)
    VALUES (${userId}, ${`load.${userId}@homolog.local`}, 'hash')
  `;
  await sql`
    INSERT INTO public.companies(id, name, price_g, price_m, price_p)
    VALUES (${compId}, 'Marmitaria Benchmark Concorrência', 20.00, 18.00, 16.00)
  `;
  await sql`
    INSERT INTO public.profiles(id, company_id, full_name, email)
    VALUES (${userId}, ${compId}, 'Operador Load', ${`load.${userId}@homolog.local`})
  `;
  await sql`INSERT INTO public.user_roles(user_id, role) VALUES (${userId}, 'admin')`;
  await sql`INSERT INTO public.financial_permissions(company_id, user_id, can_classify) VALUES (${compId}, ${userId}, true)`;
  await sql`
    INSERT INTO public.customers(id, company_id, name, phone)
    VALUES (${custId}, ${compId}, 'Cliente Concorrência', '11966665555')
  `;

  console.log("=== [2/5] Testando concorrência real: 5 inserções simultâneas do mesmo telefone com máscaras distintas ===");
  const phoneMasks = [
    "11955554444",
    "5511955554444",
    "+55 (11) 95555-4444",
    "(11) 95555-4444",
    "55 11 95555-4444",
  ];
  const phoneOutcomes = await Promise.allSettled(
    phoneMasks.map((mask, idx) =>
      asAuthenticated(userId, (tx) =>
        tx`INSERT INTO public.customers(company_id, name, phone) VALUES (${compId}, ${`Concorrente ${idx}`}, ${mask})`,
      ),
    ),
  );
  const phoneSuccesses = phoneOutcomes.filter((o) => o.status === "fulfilled").length;
  const phoneRejections = phoneOutcomes.filter((o) => o.status === "rejected").length;
  assert.strictEqual(phoneSuccesses, 1, `Esperado exatamente 1 cliente criado, obtido: ${phoneSuccesses}`);
  assert.strictEqual(phoneRejections, 4, `Esperadas 4 rejeições por duplicidade (23505), obtido: ${phoneRejections}`);
  console.log("  -> [OK] 1 inserção aceita e 4 bloqueadas por pg_advisory_xact_lock (23505).");

  console.log("=== [3/5] Testando concorrência real: 2 pagamentos simultâneos com mesma _idempotency_key ===");
  await asAuthenticated(userId, async (tx) => {
    const [row] = await tx`
      SELECT public.create_manual_or_reviewed_order(
        ${custId}::uuid, 0, 0, 5, ${today}::date, 'fiado', 'manual', ${randomUUID()}::uuid
      ) AS data
    `;
    return row.data;
  });
  const sharedPayKey = `concurrent-pay-${randomUUID()}`;
  const [payA, payB] = await Promise.all([
    asAuthenticated(userId, (tx) =>
      tx`SELECT public.register_payment(${custId}::uuid, 100.00, 'pix', 'Concorrente A', ${sharedPayKey}) AS id`,
    ),
    asAuthenticated(userId, (tx) =>
      tx`SELECT public.register_payment(${custId}::uuid, 100.00, 'pix', 'Concorrente B', ${sharedPayKey}) AS id`,
    ),
  ]);
  assert.strictEqual(payA[0].id, payB[0].id, "Duas conexões simultâneas com mesma chave devem retornar o mesmo payment_id");
  const [payCount] = await sql`SELECT count(*)::int AS n FROM public.payments WHERE customer_id = ${custId}`;
  assert.strictEqual(payCount.n, 1, "Deve existir exatamente 1 pagamento registrado");
  console.log(`  -> [OK] Pagamento único criado (${payA[0].id}) sob concorrência real.`);

  console.log("=== [4/5] Testando concorrência real: 2 workers simultâneos em claim_whatsapp_queue_batch (SKIP LOCKED) ===");
  const msgIds = Array.from({ length: 10 }, () => randomUUID());
  for (let i = 0; i < 10; i++) {
    await sql`
      INSERT INTO public.whatsapp_messages(id, company_id, phone, direction, body, status, message_uid, source)
      VALUES (${msgIds[i]}, ${compId}, '11966665555', 'inbound', 'Pedido simultâneo', 'aguardando', ${`wa:conc-${i}`}, 'whatsapp_cloud')
    `;
  }
  const [worker1Batch, worker2Batch] = await Promise.all([
    sql`SELECT id FROM public.claim_whatsapp_queue_batch(5, 60, ${compId})`,
    sql`SELECT id FROM public.claim_whatsapp_queue_batch(5, 60, ${compId})`,
  ]);
  const set1 = new Set(worker1Batch.map((r) => r.id));
  const set2 = new Set(worker2Batch.map((r) => r.id));
  for (const id of set2) {
    assert.ok(!set1.has(id), `Mensagem ${id} entregue aos dois workers simultaneamente!`);
  }
  assert.strictEqual(set1.size + set2.size, 10, "Os dois workers juntos devem reclamar exatamente as 10 mensagens");
  await sql`DELETE FROM public.whatsapp_messages WHERE company_id = ${compId}`;
  console.log(`  -> [OK] Worker 1 reclamou ${set1.size} msgs e Worker 2 reclamou ${set2.size} msgs (0 sobreposição).`);

  console.log("=== [5/5] Executando teste de carga em PostgreSQL (5, 10, 100, 500, 1.000 e 5.000 mensagens sintéticas) ===");
  const volumes = [5, 10, 100, 500, 1000, 5000];
  const loadSummary = [];

  for (const volume of volumes) {
    const subCompId = randomUUID();
    const subCustId = randomUUID();
    await sql`INSERT INTO public.companies(id, name, price_g, price_m, price_p) VALUES (${subCompId}, ${`Load ${volume}`}, 20.00, 18.00, 16.00)`;
    await sql`INSERT INTO public.customers(id, company_id, name, phone) VALUES (${subCustId}, ${subCompId}, 'Cliente Load', '11966665555')`;

    const t0 = performance.now();
    await sql`
      INSERT INTO public.whatsapp_messages(company_id, phone, direction, body, status, message_uid, source)
      SELECT ${subCompId}, '11966665555', 'inbound', 'Quero 3 G e 2 M', 'aguardando', 'wa:load-' || g::text, 'whatsapp_cloud'
      FROM generate_series(1, ${volume}) AS g
    `;

    await sql`
      DO $$
      DECLARE
        m record;
      BEGIN
        FOR m IN
          SELECT id FROM public.whatsapp_messages WHERE company_id = ${subCompId} AND status = 'aguardando'
        LOOP
          PERFORM public.complete_whatsapp_message_order(
            m.id, ${subCompId}, ${subCustId}, 0, 2, 3, ${today}::date, '{"eh_pedido":true,"qtd_g":3,"qtd_m":2,"qtd_p":0}'::jsonb
          );
        END LOOP;
      END $$;
    `;
    const elapsedMs = performance.now() - t0;

    const [stats] = await sql`
      SELECT
        (SELECT count(*)::int FROM public.orders WHERE company_id = ${subCompId}) AS orders_count,
        coalesce((SELECT sum(total) FROM public.orders WHERE company_id = ${subCompId}), 0) AS total_sum,
        (SELECT count(*)::int FROM public.whatsapp_messages WHERE company_id = ${subCompId} AND status = 'registrado') AS registered_msgs
    `;

    assert.strictEqual(stats.orders_count, volume);
    assert.strictEqual(stats.registered_msgs, volume);
    assert.strictEqual(Number(stats.total_sum), volume * 96);

    loadSummary.push({
      volume,
      ordersCreated: stats.orders_count,
      totalBrl: Number(stats.total_sum),
      elapsedMs: Number(elapsedMs.toFixed(1)),
      msgsPerSec: Math.round((volume / elapsedMs) * 1000),
    });

    await cleanupSyntheticCompanyAtomic(subCompId, null);
  }

  console.table(loadSummary);
} finally {
  await cleanupSyntheticCompanyAtomic(compId, userId);
  await sql.end();
}
