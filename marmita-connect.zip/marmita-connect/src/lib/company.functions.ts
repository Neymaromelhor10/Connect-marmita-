import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import type { SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";
import {
  requireSupabaseAuth,
  verifyRemoteSupabaseSession,
} from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";
import {
  MAX_MANUAL_RETRIES,
  MANUAL_RETRY_COOLDOWN_SECONDS,
} from "./interpret.server";

const setupSchema = z.object({
  companyName: z.string().max(120).optional().default(""),
  fullName: z.string().max(120).optional().default(""),
});

const inFlightCompanySetupByUser = new Map<string, Promise<{ companyId: string }>>();
const inFlightManualRetries = new Map<
  string,
  Promise<{ total: number; recovered: number; failed: number }>
>();

export type CompanyOperatorAuthContext = {
  supabase: SupabaseClient<Database>;
  userId: string;
  token?: string;
};

/**
 * CORREÇÃO FOR-08 & FOR-09:
 * Valida no servidor antes de executar operações privilegiadas com `supabaseAdmin`:
 * 1. Contexto autenticado (`userId` e cliente `supabase`);
 * 2. Sessão ativa e não revogada junto ao Supabase Auth (`verifyRemoteSupabaseSession`);
 * 3. Empresa vinculada ao perfil (`profiles.company_id`);
 * 4. Autorização operacional explícita via RPC `financial_require_operator()`, negando por
 *    padrão caso o usuário tenha `can_classify = false`, pertença a outra empresa ou a RPC falhe.
 */
export async function authorizeCompanyOperatorOperation(
  context: CompanyOperatorAuthContext | null | undefined,
): Promise<{ companyId: string; userId: string }> {
  if (!context?.userId || !context?.supabase) {
    throw new Error("Acesso negado: autenticação obrigatória.");
  }

  if (context.supabase.auth && typeof context.supabase.auth.getUser === "function") {
    await verifyRemoteSupabaseSession(context.supabase, context.userId, context.token);
  }

  const profile = await context.supabase
    .from("profiles")
    .select("company_id")
    .eq("id", context.userId)
    .maybeSingle();

  const companyId = profile.data?.company_id;
  if (profile.error || !companyId) {
    throw new Error("Empresa não encontrada.");
  }

  const maybeRpc = (
    context.supabase as unknown as {
      rpc?: (
        fn: string,
      ) => PromiseLike<{ data: string | null; error: { code?: string; message?: string } | null }>;
    }
  ).rpc;

  if (typeof maybeRpc !== "function") {
    throw new Error("Permissão financeira/operacional necessária.");
  }

  let opCheck: { data: string | null; error: { code?: string; message?: string } | null };
  try {
    opCheck = await maybeRpc.call(context.supabase, "financial_require_operator");
  } catch {
    throw new Error("Permissão financeira/operacional necessária.");
  }

  if (opCheck.error || !opCheck.data || opCheck.data !== companyId) {
    throw new Error("Permissão financeira/operacional necessária.");
  }

  return { companyId, userId: context.userId };
}

/**
 * CORREÇÃO AUD6-02 & AUD6-05:
 * Interpreta o resultado estruturado (JSONB) retornado por `public.prepare_manual_whatsapp_retry`.
 */
export function evaluateManualRetryPreparationOutcome(
  prepData: unknown,
  prepError: { code?: string; message?: string } | null,
):
  | { allowed: true; updatedCount: number }
  | { allowed: false; reason: string; errorCode: string; errorMessage: string } {
  if (prepError) {
    const code = prepError.code ?? "";
    if (code === "PGRST202" || code === "42883") {
      return { allowed: true, updatedCount: -1 };
    }
    return {
      allowed: false,
      reason: "RPC_ERROR",
      errorCode: code || "P0001",
      errorMessage:
        prepError.message || "Reprocessamento manual bloqueado pelas regras de segurança.",
    };
  }

  if (typeof prepData === "number") {
    return { allowed: true, updatedCount: prepData };
  }

  if (prepData && typeof prepData === "object") {
    const payload = prepData as {
      authorized?: unknown;
      updated_count?: unknown;
      outcome?: unknown;
      reason?: unknown;
      error_code?: unknown;
      message?: unknown;
    };
    const outcome = typeof payload.outcome === "string" ? payload.outcome : "";
    const reason = typeof payload.reason === "string" ? payload.reason : "";
    const errorCode = typeof payload.error_code === "string" ? payload.error_code : "P0001";
    const message = typeof payload.message === "string" ? payload.message : "";
    const updatedCount =
      typeof payload.updated_count === "number" ? payload.updated_count : 0;

    if (outcome === "blocked" || (payload.authorized === false && outcome !== "noop")) {
      return {
        allowed: false,
        reason: reason || "MANUAL_RETRY_BLOCKED",
        errorCode,
        errorMessage:
          message ||
          (reason
            ? `Reprocessamento manual bloqueado (${reason}).`
            : "Reprocessamento manual bloqueado pelas regras de segurança."),
      };
    }

    if (outcome === "noop" || updatedCount === 0) {
      return { allowed: true, updatedCount: 0 };
    }

    return { allowed: true, updatedCount: Math.max(1, updatedCount) };
  }

  return { allowed: true, updatedCount: -1 };
}

export const setupCompany = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => setupSchema.parse(data ?? {}))
  .handler(async ({ data, context }) => {
    const userId = context.userId;
    if (context.supabase?.auth && typeof context.supabase.auth.getUser === "function") {
      await verifyRemoteSupabaseSession(context.supabase, userId, context.token);
    }

    const inflight = inFlightCompanySetupByUser.get(userId);
    if (inflight) {
      return inflight;
    }

    const task = (async () => {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const existing = await supabaseAdmin
        .from("profiles")
        .select("company_id")
        .eq("id", userId)
        .maybeSingle();
      if (existing.data?.company_id) return { companyId: existing.data.company_id };

      const claimsObj = (context.claims ?? {}) as {
        email?: string | null;
        user_metadata?: { full_name?: string; name?: string; company_name?: string };
      };
      const meta = claimsObj.user_metadata ?? {};

      const resolvedCompanyName =
        data.companyName.trim() ||
        (typeof meta.company_name === "string" ? meta.company_name.trim() : "") ||
        "Minha marmitaria";

      const resolvedFullName =
        data.fullName.trim() ||
        (typeof meta.full_name === "string" ? meta.full_name.trim() : "") ||
        (typeof meta.name === "string" ? meta.name.trim() : "") ||
        claimsObj.email ||
        "Responsável";

      const company = await supabaseAdmin
        .from("companies")
        .insert({ name: resolvedCompanyName })
        .select("id")
        .single();
      if (company.error) throw new Error(company.error.message);

      const profile = await supabaseAdmin.from("profiles").insert({
        id: userId,
        company_id: company.data.id,
        full_name: resolvedFullName,
        email: claimsObj.email ?? null,
      });
      if (profile.error) {
        await supabaseAdmin.from("companies").delete().eq("id", company.data.id);
        const retryExisting = await supabaseAdmin
          .from("profiles")
          .select("company_id")
          .eq("id", userId)
          .maybeSingle();
        if (retryExisting.data?.company_id) {
          return { companyId: retryExisting.data.company_id };
        }
        throw new Error(profile.error.message);
      }

      await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "admin" });

      await supabaseAdmin
        .from("financial_permissions")
        .upsert(
          { company_id: company.data.id, user_id: userId, can_classify: true },
          { onConflict: "company_id,user_id" },
        );

      return { companyId: company.data.id };
    })();

    inFlightCompanySetupByUser.set(userId, task);
    try {
      return await task;
    } finally {
      inFlightCompanySetupByUser.delete(userId);
    }
  });

const parseSchema = z.object({
  phone: z.string().max(30).optional().default(""),
  body: z.string().min(1).max(2000),
  externalId: z.string().uuid().optional(),
  messageId: z.string().uuid().optional(),
});

export async function executeInterpretMessage(
  context: CompanyOperatorAuthContext,
  data: z.infer<typeof parseSchema>,
  deps?: {
    supabaseAdmin?: SupabaseClient<Database>;
    processIncomingMessageImpl?: typeof import("./interpret.server").processIncomingMessage;
  },
) {
  const { companyId } = await authorizeCompanyOperatorOperation(context);

  const supabaseAdmin =
    deps?.supabaseAdmin ?? (await import("@/integrations/supabase/client.server")).supabaseAdmin;
  const processIncoming =
    deps?.processIncomingMessageImpl ??
    (await import("./interpret.server")).processIncomingMessage;

  return processIncoming(supabaseAdmin, companyId, {
    ...data,
    externalId: data.externalId ? `manual:${data.externalId}` : undefined,
  });
}

export const interpretMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => parseSchema.parse(data))
  .handler(async ({ data, context }) => {
    return executeInterpretMessage(context, data);
  });

const retrySchema = z.object({
  messageId: z.string().uuid().optional(),
});

/**
 * CORREÇÃO ARGON4-01, AUD3-04, AUD5-02, AUD6-02, AUD6-05, FOR-08 & FOR-09:
 * - Exige sessão válida no servidor (`verifyRemoteSupabaseSession`) e operador autorizado (`authorizeCompanyOperatorOperation`).
 * - Valida e contabiliza o retry manual no banco via `prepare_manual_whatsapp_retry`.
 */
export const retryPendingMessages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => retrySchema.parse(data ?? {}))
  .handler(async ({ data, context }) => {
    const { companyId, userId } = await authorizeCompanyOperatorOperation(context);

    const inflightKey = `${companyId}:${data.messageId ?? "batch"}`;
    const active = inFlightManualRetries.get(inflightKey);
    if (active) {
      return active;
    }

    const task = (async () => {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const prepRpc = await supabaseAdmin.rpc("prepare_manual_whatsapp_retry", {
        _company_id: companyId,
        _message_id: data.messageId ?? null,
        _actor_id: userId,
        _max_manual_retries: MAX_MANUAL_RETRIES,
        _cooldown_seconds: MANUAL_RETRY_COOLDOWN_SECONDS,
      });

      const outcomeEval = evaluateManualRetryPreparationOutcome(prepRpc.data, prepRpc.error);
      if (!outcomeEval.allowed) {
        throw new Error(outcomeEval.errorMessage);
      }

      if (outcomeEval.updatedCount === 0) {
        return {
          total: 0,
          recovered: 0,
          failed: 0,
        };
      }

      const { drainWhatsAppQueue } = await import("./whatsapp-webhook.server");
      const workerId = `manual-retry:${userId}:${randomUUID()}`;
      const result = await drainWhatsAppQueue({
        companyId,
        messageId: data.messageId,
        limit: 25,
        concurrency: 3,
        workerId,
        supabase: supabaseAdmin,
      });

      return {
        total: result.claimed,
        recovered: result.processed,
        failed: result.failed,
      };
    })();

    inFlightManualRetries.set(inflightKey, task);
    try {
      return await task;
    } finally {
      inFlightManualRetries.delete(inflightKey);
    }
  });
