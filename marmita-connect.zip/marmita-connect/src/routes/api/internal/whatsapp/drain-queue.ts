import { createFileRoute } from "@tanstack/react-router";
import {
  authenticateCronRequest,
  inspectOperationalQueueHealth,
} from "@/lib/operational-alerts.server";
import { drainWhatsAppQueue } from "@/lib/whatsapp-webhook.server";

async function handleDrain(request: Request): Promise<Response> {
  if (!authenticateCronRequest(request)) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "content-type": "application/json; charset=utf-8" },
    });
  }

  try {
    const url = new URL(request.url);
    const limitParam = Number(url.searchParams.get("limit") ?? "15");
    const limit = Number.isFinite(limitParam) ? Math.min(Math.max(1, Math.trunc(limitParam)), 50) : 15;

    const drainResult = await drainWhatsAppQueue({ limit, concurrency: 3 });
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const health = await inspectOperationalQueueHealth(supabaseAdmin);

    return new Response(
      JSON.stringify({
        ok: true,
        drain: drainResult,
        queueHealth: health,
      }),
      {
        status: 200,
        headers: {
          "content-type": "application/json; charset=utf-8",
          "cache-control": "no-store",
        },
      },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({
        ok: false,
        error: err instanceof Error ? err.message : String(err),
      }),
      {
        status: 500,
        headers: { "content-type": "application/json; charset=utf-8" },
      },
    );
  }
}

export const Route = createFileRoute("/api/internal/whatsapp/drain-queue")({
  server: {
    handlers: {
      GET: async ({ request }) => handleDrain(request),
      POST: async ({ request }) => handleDrain(request),
    },
  },
});
