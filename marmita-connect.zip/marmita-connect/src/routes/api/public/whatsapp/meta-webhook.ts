import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { z } from "zod";

/**
 * Webhook da Meta WhatsApp Cloud API (somente RECEBIMENTO).
 * GET  -> verificação do webhook (hub.challenge) com WHATSAPP_VERIFY_TOKEN.
 * POST -> mensagens recebidas (messages) e ecos comerciais da marmitaria (smb_message_echoes),
 *         assinados com X-Hub-Signature-256 (WHATSAPP_APP_SECRET).
 *         CORREÇÃO ARGON4-03: Persiste tanto mensagens quanto ecos comerciais OK/OKK
 *         na fila durável (`status = 'aguardando'`) ANTES do retorno HTTP 200 e aciona
 *         o worker assíncrono com coalescência (scheduleDrainWhatsAppQueue), sem bloquear
 *         o ACK da Meta e sem perder confirmações enviadas enquanto o Gemini processa.
 */

const textMessage = z.object({
  id: z.string().min(1).max(200),
  from: z.string().min(3).max(32),
  to: z.string().min(3).max(32).optional(),
  recipient_id: z.string().min(3).max(32).optional(),
  timestamp: z.string().max(20).optional(),
  type: z.string(),
  text: z.object({ body: z.string().max(4096) }).optional(),
  context: z
    .object({
      id: z.string().optional(),
      forwarded: z.boolean().optional(),
      frequently_forwarded: z.boolean().optional(),
    })
    .passthrough()
    .optional(),
});

const payloadSchema = z.object({
  object: z.string(),
  entry: z
    .array(
      z.object({
        id: z.string().optional(),
        changes: z.array(
          z.object({
            field: z.string(),
            value: z
              .object({
                metadata: z
                  .object({
                    phone_number_id: z.string(),
                    display_phone_number: z.string().optional(),
                  })
                  .partial()
                  .optional(),
                contacts: z
                  .array(
                    z.object({
                      wa_id: z.string().optional(),
                      profile: z.object({ name: z.string().optional() }).optional(),
                    }),
                  )
                  .optional(),
                messages: z.array(z.unknown()).optional(),
                message_echoes: z.array(z.unknown()).optional(),
              })
              .passthrough(),
          }),
        ),
      }),
    )
    .max(50),
});

export function validSignature(raw: string, header: string | null, secret: string) {
  if (!header?.startsWith("sha256=")) return false;
  const expected = createHmac("sha256", secret).update(raw).digest("hex");
  const a = Buffer.from(header.slice(7), "hex");
  const b = Buffer.from(expected, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

export type ExtractedMessage = {
  messageId: string;
  from: string;
  profileName: string | null;
  text: string;
  timestamp: string | null;
  phoneNumberId: string;
  wabaId: string | null;
};

export type ExtractedBusinessEcho = {
  messageId: string;
  from: string;
  to: string;
  text: string;
  timestamp: string | null;
  phoneNumberId: string;
  wabaId: string | null;
  quoted: boolean;
  forwarded: boolean;
  standalone: boolean;
};

export function extractMessages(payload: z.infer<typeof payloadSchema>): ExtractedMessage[] {
  const out: ExtractedMessage[] = [];
  for (const entry of payload.entry) {
    for (const change of entry.changes) {
      if (change.field !== "messages") continue;
      const phoneNumberId = change.value.metadata?.phone_number_id;
      if (!phoneNumberId) continue;
      for (const m of change.value.messages ?? []) {
        const msg = textMessage.safeParse(m);
        if (!msg.success || msg.data.type !== "text" || !msg.data.text?.body.trim()) continue;
        const contact = change.value.contacts?.find((c) => c.wa_id === msg.data.from);
        out.push({
          messageId: msg.data.id,
          from: msg.data.from.replace(/\D/g, ""),
          profileName: contact?.profile?.name ?? null,
          text: msg.data.text.body.trim().slice(0, 2000),
          timestamp: msg.data.timestamp ?? null,
          phoneNumberId,
          wabaId: entry.id ?? null,
        });
      }
    }
  }
  return out;
}

export function extractBusinessEchoes(
  payload: z.infer<typeof payloadSchema>,
): ExtractedBusinessEcho[] {
  const out: ExtractedBusinessEcho[] = [];
  for (const entry of payload.entry) {
    for (const change of entry.changes) {
      if (change.field !== "smb_message_echoes" && !change.value.message_echoes) continue;
      const phoneNumberId = change.value.metadata?.phone_number_id;
      if (!phoneNumberId) continue;
      const list = change.value.message_echoes ?? change.value.messages ?? [];
      for (const rawEcho of list) {
        const echo = textMessage.safeParse(rawEcho);
        if (!echo.success || echo.data.type !== "text" || !echo.data.text?.body) continue;
        const recipient = (echo.data.to ?? echo.data.recipient_id ?? "").replace(/\D/g, "");
        if (!recipient) continue;
        const ctx = echo.data.context;
        const quoted = Boolean(ctx?.id);
        const forwarded = Boolean(ctx?.forwarded || ctx?.frequently_forwarded);
        out.push({
          messageId: echo.data.id,
          from: echo.data.from.replace(/\D/g, ""),
          to: recipient,
          text: echo.data.text.body,
          timestamp: echo.data.timestamp ?? null,
          phoneNumberId,
          wabaId: entry.id ?? null,
          quoted,
          forwarded,
          standalone: !quoted && !forwarded,
        });
      }
    }
  }
  return out;
}

export const Route = createFileRoute("/api/public/whatsapp/meta-webhook")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const verifyToken = process.env["WHATSAPP_VERIFY_TOKEN"];
        if (!verifyToken) return new Response("Webhook não configurado", { status: 503 });
        const url = new URL(request.url);
        const mode = url.searchParams.get("hub.mode");
        const token = url.searchParams.get("hub.verify_token") ?? "";
        const challenge = url.searchParams.get("hub.challenge") ?? "";
        const a = Buffer.from(token);
        const b = Buffer.from(verifyToken);
        if (mode === "subscribe" && a.length === b.length && timingSafeEqual(a, b)) {
          return new Response(challenge, { status: 200, headers: { "content-type": "text/plain" } });
        }
        return new Response("Forbidden", { status: 403 });
      },

      POST: async ({ request }) => {
        const appSecret = process.env["WHATSAPP_APP_SECRET"];
        if (!appSecret) return new Response("Webhook não configurado", { status: 503 });

        const raw = await request.text();
        if (raw.length > 1_000_000) return new Response("Payload grande demais", { status: 413 });
        if (!validSignature(raw, request.headers.get("x-hub-signature-256"), appSecret)) {
          return new Response("Assinatura inválida", { status: 401 });
        }

        let json: unknown;
        try {
          json = JSON.parse(raw);
        } catch {
          return new Response("JSON inválido", { status: 400 });
        }
        const parsed = payloadSchema.safeParse(json);
        if (!parsed.success || parsed.data.object !== "whatsapp_business_account") {
          return new Response("ok", { status: 200 });
        }

        const {
          enqueueMetaMessages,
          enqueueMetaBusinessEchoes,
          scheduleDrainWhatsAppQueue,
        } = await import("@/lib/whatsapp-webhook.server");

        try {
          let hasNewQueuedItems = false;

          const inbound = extractMessages(parsed.data);
          if (inbound.length > 0) {
            const enqueued = await enqueueMetaMessages(inbound);
            if (enqueued.enqueuedIds.length > 0) {
              hasNewQueuedItems = true;
            }
          }

          const echoes = extractBusinessEchoes(parsed.data);
          if (echoes.length > 0) {
            const enqueuedEchoes = await enqueueMetaBusinessEchoes(echoes);
            if (enqueuedEchoes.enqueuedIds.length > 0) {
              hasNewQueuedItems = true;
            }
          }

          if (hasNewQueuedItems) {
            // Aciona o worker assíncrono com coalescência (singleflight) em background
            // sem bloquear a resposta HTTP 200 da Meta.
            void scheduleDrainWhatsAppQueue({ limit: 15, concurrency: 3 }).catch((err) => {
              console.error("[whatsapp-webhook] falha assíncrona no worker de fila", err);
            });
          }
        } catch (err) {
          console.error("[whatsapp-webhook] falha ao persistir evento na fila durável", err);
          return new Response("Erro ao persistir", { status: 500 });
        }
        return new Response("ok", { status: 200 });
      },
    },
  },
});
