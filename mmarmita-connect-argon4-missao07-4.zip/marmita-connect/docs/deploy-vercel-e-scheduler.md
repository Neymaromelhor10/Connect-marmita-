# Guia de Deploy na Vercel e Scheduler Durável da Fila WhatsApp (`AF-02`)

## 1. Arquitetura de Durabilidade da Fila (`public.whatsapp_messages`)

O processamento de mensagens recebidas pela Meta WhatsApp Cloud API (`POST /api/public/whatsapp/meta-webhook`) utiliza três camadas complementares de durabilidade:

1. **Persistência Transacional Pré-ACK**:
   - Toda mensagem inbound e todo eco comercial (`OK` / `OKK`) é gravado em `public.whatsapp_messages` (`status = 'aguardando'`) **antes** do retorno `HTTP 200` para a Meta.
2. **Integração com `waitUntil` Oficial do Runtime Vercel (`Symbol.for("@vercel/request-context")`) + Micro-Batch**:
   - Em `src/routes/api/public/whatsapp/meta-webhook.ts`, `extractRuntimeWaitUntil` obtém a função `waitUntil` diretamente do registrador global `Symbol.for("@vercel/request-context")` (a API oficial do runtime Vercel Serverless / Fluid Compute usada por `@vercel/functions`), registrando a promise de `scheduleDrainWhatsAppQueue` para que a instância não seja congelada prematuramente após o envio do `HTTP 200`.
3. **Recuperação Automática por Expiração de Lease e Scheduler (`/api/internal/whatsapp/drain-queue`)**:
   - Caso uma instância serverless sofra *cold stop* ou falha de rede durante a chamada ao Gemini, o lease (`locked_until`) expira em 90 segundos e a mensagem é recuperada de forma segura por `claim_whatsapp_queue_batch` (`FOR UPDATE SKIP LOCKED`) com incremento monotônico de `lease_generation`.

## 2. Compatibilidade do Cron entre Planos Vercel Hobby e Vercel Pro

- **Configuração padrão em `vercel.json` (`"schedule": "0 3 * * *"`)**:
  - Contas **Vercel Hobby** permitem agendamentos Cron com frequência máxima de **1 vez por dia** (deploys com `* * * * *` são bloqueados pela plataforma no plano Hobby). Por isso, `vercel.json` está configurado com `"0 3 * * *"` (diário às 03:00 UTC), garantindo deploy imediato tanto em contas Hobby quanto Pro.
- **Para drenagem a cada 1 minuto em Produção**:
  - **Opção A (Plano Vercel Pro)**: altere `"schedule"` em `vercel.json` para `"* * * * *"`. A Vercel enviará automaticamente `Authorization: Bearer <CRON_SECRET>` a cada minuto para `/api/internal/whatsapp/drain-queue`.
  - **Opção B (Plano Vercel Hobby + Supabase `pg_cron` / `pg_net` ou GitHub Actions)**: mantenha `"0 3 * * *"` em `vercel.json` e configure no SQL Editor do Supabase um job `pg_cron` (gratuito no Supabase) para acionar o endpoint protegido a cada minuto:
    ```sql
    SELECT cron.schedule(
      'marmita-connect-drain-whatsapp-queue',
      '* * * * *',
      $$
      SELECT net.http_post(
        url := 'https://SEU-DOMINIO.vercel.app/api/internal/whatsapp/drain-queue',
        headers := jsonb_build_object(
          'Authorization', 'Bearer SEU_CRON_SECRET',
          'Content-Type', 'application/json'
        ),
        body := '{}'::jsonb
      );
      $$
    );
    ```
